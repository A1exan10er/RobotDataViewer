#!/usr/bin/env python3
"""
批量 DIS 光流。

模式 1（folders）：每个文件夹内 Origin0.jpg 为基准。
模式 2（i0_i1）：I0/I1 两个目录中成对图像计算光流。

用法:
  python batch_flow/batch_flow.py --config batch_flow/batch_flow.yaml
  python batch_flow/batch_flow.py --config batch_flow/batch_flow_folders.yaml
"""

from __future__ import annotations

import argparse
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, List, Literal, Optional, Tuple

import cv2
import numpy as np

from optical_flow_dis import (
    analyze_flow,
    amplitude_to_gray,
    compute_dis_flow,
    create_dis_flow,
    draw_final_flow_black,
    draw_flow_arrows,
    draw_flow_on_image,
    flow_to_hsv_image,
    flow_to_polar_int16,
    optical_flow_dis_original,
    to_gray,
)

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif", ".webp"}
DEFAULT_FLOW_SIZE: Tuple[int, int] = (640, 480)
ReferenceMode = Literal["origin0", "consecutive", "first"]
PairMode = Literal["folders", "i0_i1"]
NpzSaveMode = Literal["float16", "polar", "full"]


def parse_size(text: str) -> Tuple[int, int]:
    w, h = text.lower().replace(" ", "").split("x")
    return int(w), int(h)


def normalize_frame_size(frame: np.ndarray, size: Tuple[int, int]) -> np.ndarray:
    w, h = size
    if frame.shape[1] != w or frame.shape[0] != h:
        return cv2.resize(frame, (w, h))
    return frame


class _TextProgressBar:
    """无 tqdm 时的简易进度条。"""

    def __init__(self, total: int, desc: str):
        self.total = max(total, 1)
        self.desc = desc
        self.n = 0
        self._t0 = time.time()
        self._postfix = ""

    def set_postfix(self, **kwargs) -> None:
        self._postfix = " ".join(f"{k}={v}" for k, v in kwargs.items())

    def update(self, n: int = 1) -> None:
        self.n += n
        elapsed = time.time() - self._t0
        rate = self.n / elapsed if elapsed > 0 else 0.0
        eta = (self.total - self.n) / rate if rate > 0 else 0.0
        pct = 100.0 * self.n / self.total
        width = 32
        filled = int(width * self.n / self.total)
        bar = "=" * filled + "-" * (width - filled)
        extra = f" | {self._postfix}" if self._postfix else ""
        print(
            f"\r{self.desc} [{bar}] {self.n}/{self.total} ({pct:5.1f}%) "
            f"{rate:.2f}张/s ETA {eta:5.0f}s{extra}   ",
            end="",
            flush=True,
        )

    def close(self) -> None:
        print(flush=True)


def update_progress_bar(bar, n: int = 1, **postfix) -> None:
    if postfix:
        if hasattr(bar, "set_postfix"):
            bar.set_postfix(ok=postfix.get("ok", 0), fail=postfix.get("fail", 0),
                            skip=postfix.get("skip", 0), refresh=True)
        elif isinstance(bar, _TextProgressBar):
            bar.set_postfix(**postfix)
    if hasattr(bar, "update"):
        bar.update(n)


def load_yaml_config(path: Path) -> dict[str, Any]:
    try:
        import yaml
    except ImportError as e:
        raise SystemExit("读取 YAML 需要 PyYAML: pip install pyyaml") from e
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SystemExit(f"YAML 根节点必须是字典: {path}")
    return data


def iter_images(root: Path, recursive: bool) -> List[Path]:
    if recursive:
        paths = sorted(p for p in root.rglob("*") if p.is_file())
    else:
        paths = sorted(p for p in root.iterdir() if p.is_file())
    return [p for p in paths if p.suffix.lower() in IMAGE_EXTENSIONS]


def find_reference_image(input_dir: Path, ref_name: str) -> Optional[Path]:
    """查找基准图 Origin0.jpg（大小写不敏感）。"""
    target = ref_name.lower()
    for p in iter_images(input_dir, recursive=False):
        if p.name.lower() == target:
            return p
    # 递归时也在根目录找
    for p in input_dir.iterdir():
        if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS and p.name.lower() == target:
            return p
    return None


def resolve_output_dir(input_dir: Path, settings: "FlowSettings") -> Path:
    """
    输出目录与图像文件夹同级（同一父路径下）。
    例: .../Original_Images_post/  ->  .../Optical_Flow/
    """
    folder_name = settings.output_subdir or "Optical_Flow"
    if settings.output_root is not None:
        return settings.output_root / folder_name
    return input_dir.parent / folder_name


def resize_if_needed(frame: np.ndarray, size: Optional[Tuple[int, int]]) -> np.ndarray:
    if size is None:
        return frame
    w, h = size
    if frame.shape[1] == w and frame.shape[0] == h:
        return frame
    return normalize_frame_size(frame, size)


@dataclass
class I0I1Job:
    i0_dir: Path
    i1_dir: Path
    output_dir: Path


@dataclass
class FlowSettings:
    mode: PairMode
    folders: List[Path]
    dataset_roots: List[Path]
    i0_dir: Optional[Path]
    i1_dir: Optional[Path]
    output_root: Optional[Path]
    output_subdir: Optional[str]
    suffix: str
    reference: ReferenceMode
    reference_name: str
    resize: Optional[Tuple[int, int]]
    dis_style: str
    finest_scale: int
    patch_size: int
    patch_stride: int
    gradient_descent_iterations: int
    variational_refinement_iterations: int
    variational_refinement_alpha: float
    variational_refinement_delta: float
    variational_refinement_gamma: float
    blur_ksize: int
    arrow_step: int
    arrow_scale: float
    min_magnitude: float
    save_npz: bool
    npz_save_mode: NpzSaveMode
    save_hsv: bool
    save_arrow: bool
    save_amp: bool
    save_overlay: bool
    arrow_style: str
    recursive: bool
    skip_existing: bool
    flow_filename_prefix: str
    flow_filename_suffix: str
    flow_filename_strip_prefix: str
    flow_filename_strip_suffix: str
    i0_suffix: str
    i1_suffix: str


def flow_npz_stem(image_stem: str, settings: FlowSettings) -> str:
    """
    光流文件名。例:
      O_Image3-0-1-0.1-0.0-x -> OpticalFlow3-0-1-0.1-0.0-x
      000001_Sim_0001_I1 -> 000001_Sim_0001_Optical_Flow
    """
    stem = image_stem
    strip_prefix = settings.flow_filename_strip_prefix
    if strip_prefix and stem.startswith(strip_prefix):
        stem = stem[len(strip_prefix):]
    strip_suffix = settings.flow_filename_strip_suffix
    if strip_suffix and stem.endswith(strip_suffix):
        stem = stem[: -len(strip_suffix)]
    return f"{settings.flow_filename_prefix}{stem}{settings.flow_filename_suffix}"


def collect_i0_i1_pairs(
    i0_dir: Path,
    i1_dir: Path,
    settings: FlowSettings,
) -> List[Tuple[Path, Path]]:
    """I0/I1 目录中按文件名一一配对。"""
    i0_dir = i0_dir.expanduser().resolve()
    i1_dir = i1_dir.expanduser().resolve()
    if not i0_dir.is_dir():
        raise SystemExit(f"找不到 I0 目录: {i0_dir}")
    if not i1_dir.is_dir():
        raise SystemExit(f"找不到 I1 目录: {i1_dir}")

    pairs: List[Tuple[Path, Path]] = []
    missing: List[str] = []
    i0_files = sorted(
        p for p in i0_dir.iterdir()
        if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS
    )
    for i0_path in i0_files:
        name = i0_path.name
        if settings.i0_suffix and settings.i0_suffix in name:
            i1_name = name.replace(settings.i0_suffix, settings.i1_suffix, 1)
        elif name.endswith("_I0.png"):
            i1_name = name.replace("_I0.", "_I1.")
        else:
            i1_name = f"{i0_path.stem}{settings.i1_suffix}{i0_path.suffix}"

        i1_path = i1_dir / i1_name
        if not i1_path.is_file():
            missing.append(name)
            continue
        pairs.append((i0_path, i1_path))

    if missing:
        print(f"[警告] {len(missing)} 个 I0 找不到对应 I1，例如: {missing[:3]}")
    if not pairs:
        raise SystemExit(f"未找到任何 I0/I1 配对: {i0_dir} <-> {i1_dir}")
    return pairs


def resolve_pair_output_dir(settings: FlowSettings) -> Path:
    folder_name = settings.output_subdir or "Optical_Flow"
    if settings.output_root is not None:
        return settings.output_root / folder_name
    if settings.i0_dir is not None:
        return settings.i0_dir.expanduser().resolve().parent / folder_name
    raise SystemExit("i0_i1 模式需要 output_root 或 i0_dir")


def list_i0_i1_jobs(settings: FlowSettings) -> List[I0I1Job]:
    folder_name = settings.output_subdir or "Optical_Flow"
    jobs: List[I0I1Job] = []

    if settings.dataset_roots:
        for root in settings.dataset_roots:
            base = root.expanduser().resolve()
            jobs.append(I0I1Job(base / "I0", base / "I1", base / folder_name))
    elif settings.i0_dir and settings.i1_dir:
        jobs.append(I0I1Job(
            settings.i0_dir.expanduser().resolve(),
            settings.i1_dir.expanduser().resolve(),
            resolve_pair_output_dir(settings).resolve(),
        ))
    else:
        raise SystemExit("i0_i1 模式需要 dataset_roots 或 i0_dir + i1_dir")

    return jobs


def settings_from_yaml(cfg: dict[str, Any], extra: List[Path]) -> FlowSettings:
    i0_dir_raw = cfg.get("i0_dir")
    i1_dir_raw = cfg.get("i1_dir")
    dataset_roots_raw = cfg.get("dataset_roots") or []
    dataset_roots: List[Path] = []
    for item in dataset_roots_raw:
        if isinstance(item, str):
            dataset_roots.append(Path(item).expanduser())
        else:
            raise SystemExit(f"dataset_roots 项格式错误: {item!r}")

    mode_raw = str(cfg.get(
        "mode",
        "i0_i1" if (dataset_roots or (i0_dir_raw and i1_dir_raw)) else "folders",
    )).lower()
    if mode_raw not in ("folders", "i0_i1"):
        raise SystemExit("mode 只能是 folders | i0_i1")

    raw = cfg.get("folders") or []
    folders: List[Path] = []
    for item in raw:
        if isinstance(item, str):
            folders.append(Path(item).expanduser())
        elif isinstance(item, dict) and "path" in item:
            folders.append(Path(str(item["path"])).expanduser())
        else:
            raise SystemExit(f"folders 项格式错误: {item!r}")
    folders.extend(extra)

    if mode_raw == "folders" and not folders:
        raise SystemExit("folders 模式需要配置 folders，或改用 i0_i1 模式")
    if mode_raw == "i0_i1" and not dataset_roots and (not i0_dir_raw or not i1_dir_raw):
        raise SystemExit("i0_i1 模式需要 dataset_roots 或 i0_dir + i1_dir")

    resize_raw = cfg.get("resize", "640x480")
    resize = parse_size(str(resize_raw)) if resize_raw else DEFAULT_FLOW_SIZE
    out_root = cfg.get("output_root")
    ref = str(cfg.get("reference", "origin0")).lower()
    if ref not in ("origin0", "consecutive", "first"):
        raise SystemExit("reference 只能是 origin0 | consecutive | first")

    npz_mode = str(cfg.get("npz_save_mode", "float16")).lower()
    if npz_mode not in ("float16", "polar", "full"):
        raise SystemExit("npz_save_mode 只能是 float16 | polar | full")

    return FlowSettings(
        mode=mode_raw,  # type: ignore[arg-type]
        folders=folders,
        dataset_roots=dataset_roots,
        i0_dir=Path(i0_dir_raw).expanduser() if i0_dir_raw else None,
        i1_dir=Path(i1_dir_raw).expanduser() if i1_dir_raw else None,
        output_root=Path(out_root).expanduser() if out_root else None,
        output_subdir=str(cfg.get("output_subdir", "Optical_Flow")),
        suffix=str(cfg.get("suffix", "_flow")),
        reference=ref,  # type: ignore[arg-type]
        reference_name=str(cfg.get("reference_name", "Origin0.jpg")),
        resize=resize,
        dis_style=str(cfg.get("dis_style", "original")),
        finest_scale=int(cfg.get("finest_scale", 2)),
        patch_size=int(cfg.get("patch_size", 4)),
        patch_stride=int(cfg.get("patch_stride", 2)),
        gradient_descent_iterations=int(cfg.get("gradient_descent_iterations", 25)),
        variational_refinement_iterations=int(cfg.get("variational_refinement_iterations", 5)),
        variational_refinement_alpha=float(cfg.get("variational_refinement_alpha", 20.0)),
        variational_refinement_delta=float(cfg.get("variational_refinement_delta", 5.0)),
        variational_refinement_gamma=float(cfg.get("variational_refinement_gamma", 10.0)),
        blur_ksize=int(cfg.get("blur_ksize", 0)),
        arrow_step=int(cfg.get("arrow_step", 16)),
        arrow_scale=float(cfg.get("arrow_scale", 10.0)),
        min_magnitude=float(cfg.get("min_magnitude", 0.0)),
        save_npz=bool(cfg.get("save_npz", cfg.get("save_npy", True))),
        npz_save_mode=npz_mode,  # type: ignore[arg-type]
        save_hsv=bool(cfg.get("save_hsv", False)),
        save_arrow=bool(cfg.get("save_arrow", False)),
        save_amp=bool(cfg.get("save_amp", False)),
        save_overlay=bool(cfg.get("save_overlay", False)),
        arrow_style=str(cfg.get("arrow_style", "final_flow")),
        recursive=bool(cfg.get("recursive", False)),
        skip_existing=bool(cfg.get("skip_existing", False)),
        flow_filename_prefix=str(cfg.get("flow_filename_prefix", "OpticalFlow")),
        flow_filename_suffix=str(cfg.get("flow_filename_suffix", "")),
        flow_filename_strip_prefix=str(cfg.get("flow_filename_strip_prefix", "O_Image")),
        flow_filename_strip_suffix=str(cfg.get("flow_filename_strip_suffix", "")),
        i0_suffix=str(cfg.get("i0_suffix", "_I0")),
        i1_suffix=str(cfg.get("i1_suffix", "_I1")),
    )


def flow_output_paths(output_dir: Path, stem: str, settings: FlowSettings) -> List[Path]:
    paths: List[Path] = []
    if settings.save_npz:
        paths.append(output_dir / f"{stem}.npz")
    if settings.save_hsv:
        paths.append(output_dir / f"{stem}_hsv.png")
    if settings.save_arrow:
        paths.append(output_dir / f"{stem}_arrow.png")
    if settings.save_amp:
        paths.append(output_dir / f"{stem}_amp.png")
    if settings.save_overlay:
        paths.append(output_dir / f"{stem}_overlay.png")
    return paths


def all_outputs_exist(output_dir: Path, stem: str, settings: FlowSettings) -> bool:
    paths = flow_output_paths(output_dir, stem, settings)
    return bool(paths) and all(p.is_file() for p in paths)


def save_flow_outputs(
    output_dir: Path,
    stem: str,
    flow: np.ndarray,
    polar: Optional[np.ndarray],
    cur_bgr: np.ndarray,
    settings: FlowSettings,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    if settings.save_npz:
        if polar is None:
            polar = flow_to_polar_int16(flow)
        out_path = str(output_dir / f"{stem}.npz")
        mode = settings.npz_save_mode
        if mode == "full":
            np.savez_compressed(out_path, flow=flow.astype(np.float32), polar=polar)
        elif mode == "float16":
            np.savez_compressed(out_path, flow=flow.astype(np.float16))
        elif mode == "polar":
            np.savez_compressed(out_path, polar=polar.astype(np.int16))
        else:
            raise ValueError(f"未知 npz_save_mode: {mode}")

    if settings.save_hsv:
        cv2.imwrite(str(output_dir / f"{stem}_hsv.png"), flow_to_hsv_image(flow))

    if settings.save_arrow:
        # Final_Flow: 黑底，箭头长度 = 1*u, 1*v
        cv2.imwrite(
            str(output_dir / f"{stem}_arrow.png"),
            draw_final_flow_black(flow, step=settings.arrow_step, arrow_scale=1.0),
        )

    if settings.save_amp:
        cv2.imwrite(
            str(output_dir / f"{stem}_amp.png"),
            amplitude_to_gray(analyze_flow(flow).amplitude),
        )

    if settings.save_overlay:
        cv2.imwrite(
            str(output_dir / f"{stem}_overlay.png"),
            draw_flow_on_image(
                cur_bgr, flow,
                step=settings.arrow_step,
                arrow_scale=settings.arrow_scale,
            ),
        )


def compute_and_save_flow(
    ref_gray: np.ndarray,
    cur_gray: np.ndarray,
    cur_bgr: np.ndarray,
    out_stem: str,
    output_dir: Path,
    dis,
    settings: FlowSettings,
) -> None:
    if settings.dis_style == "original":
        flow, polar = optical_flow_dis_original(ref_gray, cur_gray, dis)
    else:
        flow = compute_dis_flow(ref_gray, cur_gray, dis)
        polar = flow_to_polar_int16(flow)
    save_flow_outputs(output_dir, out_stem, flow, polar, cur_bgr, settings)


def process_i0_i1_pairs(
    pairs: List[Tuple[Path, Path]],
    output_dir: Path,
    dis,
    settings: FlowSettings,
) -> Tuple[int, int, int]:
    output_dir.mkdir(parents=True, exist_ok=True)
    ok, fail, skip = 0, 0, 0
    total = len(pairs)
    print(
        f"\n=== I0/I1 配对 {total} 组 -> {output_dir} ==="
    )

    desc = "I0->I1 flow"
    try:
        from tqdm import tqdm
        progress_bar = tqdm(total=total, desc=desc, unit="对", dynamic_ncols=True)
    except ImportError:
        progress_bar = _TextProgressBar(total, desc)

    for i0_path, i1_path in pairs:
        out_stem = flow_npz_stem(i1_path.stem, settings)
        if settings.skip_existing and all_outputs_exist(output_dir, out_stem, settings):
            skip += 1
            update_progress_bar(progress_bar, ok=ok, fail=fail, skip=skip)
            continue

        ref_bgr = cv2.imread(str(i0_path))
        cur_bgr = cv2.imread(str(i1_path))
        if ref_bgr is None or cur_bgr is None:
            fail += 1
            if isinstance(progress_bar, _TextProgressBar):
                print(f"\n  无法读取: {i0_path.name} / {i1_path.name}", flush=True)
            elif hasattr(progress_bar, "write"):
                progress_bar.write(f"无法读取: {i0_path.name} / {i1_path.name}")
            update_progress_bar(progress_bar, ok=ok, fail=fail, skip=skip)
            continue

        ref_bgr = resize_if_needed(ref_bgr, settings.resize)
        cur_bgr = resize_if_needed(cur_bgr, settings.resize)
        ref_gray = to_gray(ref_bgr, settings.blur_ksize)
        cur_gray = to_gray(cur_bgr, settings.blur_ksize)

        try:
            compute_and_save_flow(
                ref_gray, cur_gray, cur_bgr, out_stem, output_dir, dis, settings,
            )
            ok += 1
        except Exception as e:
            fail += 1
            if isinstance(progress_bar, _TextProgressBar):
                print(f"\n  光流失败 {i1_path.name}: {e}", flush=True)
            elif hasattr(progress_bar, "write"):
                progress_bar.write(f"光流失败 {i1_path.name}: {e}")

        update_progress_bar(progress_bar, ok=ok, fail=fail, skip=skip)

    if hasattr(progress_bar, "close"):
        progress_bar.close()

    print(f"  完成: 成功 {ok} | 失败 {fail} | 跳过 {skip} / {total}")
    return ok, fail, skip


def process_folder_origin0(
    input_dir: Path,
    output_dir: Path,
    dis,
    settings: FlowSettings,
) -> Tuple[int, int, int]:
    ref_path = find_reference_image(input_dir, settings.reference_name)
    if ref_path is None:
        print(f"[跳过] 未找到基准图 {settings.reference_name}: {input_dir}")
        return 0, 0, 0

    ref_bgr = cv2.imread(str(ref_path))
    if ref_bgr is None:
        print(f"[跳过] 无法读取基准图: {ref_path}")
        return 0, 1, 0
    ref_bgr = resize_if_needed(ref_bgr, settings.resize)
    ref_gray = to_gray(ref_bgr, settings.blur_ksize)

    images = iter_images(input_dir, settings.recursive)
    targets = [p for p in images if p.resolve() != ref_path.resolve()]
    if not targets:
        print(f"[跳过] 除基准外无其它图像: {input_dir}")
        return 0, 0, 0

    output_dir.mkdir(parents=True, exist_ok=True)
    ok, fail, skip = 0, 0, 0
    total = len(targets)
    print(
        f"\n=== {input_dir} -> {output_dir} "
        f"(基准 {ref_path.name}, 待算 {total} 张) ==="
    )

    desc = input_dir.name[:40]
    progress_bar = None
    try:
        from tqdm import tqdm
        progress_bar = tqdm(total=total, desc=desc, unit="张", dynamic_ncols=True)
    except ImportError:
        progress_bar = _TextProgressBar(total, desc)

    for cur_path in targets:
        out_stem = flow_npz_stem(cur_path.stem, settings)
        if settings.skip_existing and all_outputs_exist(output_dir, out_stem, settings):
            skip += 1
            update_progress_bar(progress_bar, ok=ok, fail=fail, skip=skip)
            continue

        cur_bgr = cv2.imread(str(cur_path))
        if cur_bgr is None:
            fail += 1
            update_progress_bar(progress_bar, ok=ok, fail=fail, skip=skip)
            continue
        cur_bgr = resize_if_needed(cur_bgr, settings.resize)
        cur_gray = to_gray(cur_bgr, settings.blur_ksize)

        try:
            compute_and_save_flow(
                ref_gray, cur_gray, cur_bgr, out_stem, output_dir, dis, settings,
            )
            ok += 1
        except Exception as e:
            fail += 1
            if isinstance(progress_bar, _TextProgressBar):
                print(f"\n  光流失败 {cur_path.name}: {e}", flush=True)
            elif hasattr(progress_bar, "write"):
                progress_bar.write(f"光流失败 {cur_path.name}: {e}")

        update_progress_bar(progress_bar, ok=ok, fail=fail, skip=skip)

    if hasattr(progress_bar, "close"):
        progress_bar.close()

    print(f"  完成: 成功 {ok} | 失败 {fail} | 跳过 {skip} / {total}")
    return ok, fail, skip


def process_folder_sequential(
    input_dir: Path,
    output_dir: Path,
    dis,
    settings: FlowSettings,
) -> Tuple[int, int, int]:
    images = iter_images(input_dir, settings.recursive)
    if len(images) < 2:
        print(f"[跳过] 图像少于 2 张: {input_dir}")
        return 0, 0, 0

    output_dir.mkdir(parents=True, exist_ok=True)
    ok, fail, skip = 0, 0, 0
    total = len(images) - 1
    print(f"\n=== {input_dir} -> {output_dir} ({len(images)} 张, ref={settings.reference}) ===")

    desc = input_dir.name[:40]
    try:
        from tqdm import tqdm
        progress_bar = tqdm(total=total, desc=desc, unit="张", dynamic_ncols=True)
    except ImportError:
        progress_bar = _TextProgressBar(total, desc)

    first_bgr = cv2.imread(str(images[0]))
    if first_bgr is None:
        print(f"  无法读取首帧: {images[0]}")
        return 0, 1, 0
    first_bgr = resize_if_needed(first_bgr, settings.resize)
    ref_gray = to_gray(first_bgr, settings.blur_ksize)
    prev_gray = ref_gray

    for idx in range(1, len(images)):
        cur_path = images[idx]
        cur_bgr = cv2.imread(str(cur_path))
        if cur_bgr is None:
            fail += 1
            update_progress_bar(progress_bar, ok=ok, fail=fail, skip=skip)
            continue
        cur_bgr = resize_if_needed(cur_bgr, settings.resize)
        cur_gray = to_gray(cur_bgr, settings.blur_ksize)
        prev_for_flow = ref_gray if settings.reference == "first" else prev_gray
        out_stem = flow_npz_stem(cur_path.stem, settings)

        if settings.skip_existing and all_outputs_exist(output_dir, out_stem, settings):
            skip += 1
            prev_gray = cur_gray
            update_progress_bar(progress_bar, ok=ok, fail=fail, skip=skip)
            continue

        try:
            compute_and_save_flow(
                prev_for_flow, cur_gray, cur_bgr, out_stem, output_dir, dis, settings,
            )
            ok += 1
        except Exception as e:
            fail += 1
            if hasattr(progress_bar, "write"):
                progress_bar.write(f"光流失败 {cur_path.name}: {e}")
            else:
                print(f"\n  光流失败 {cur_path.name}: {e}", flush=True)
        prev_gray = cur_gray
        update_progress_bar(progress_bar, ok=ok, fail=fail, skip=skip)

    if hasattr(progress_bar, "close"):
        progress_bar.close()

    print(f"  完成: 成功 {ok} | 失败 {fail} | 跳过 {skip} / {total}")
    return ok, fail, skip


def process_folder(
    input_dir: Path,
    output_dir: Path,
    dis,
    settings: FlowSettings,
) -> Tuple[int, int, int]:
    if settings.reference == "origin0":
        return process_folder_origin0(input_dir, output_dir, dis, settings)
    return process_folder_sequential(input_dir, output_dir, dis, settings)


def main() -> int:
    parser = argparse.ArgumentParser(description="批量 DIS 光流（默认相对 Origin0.jpg）")
    parser.add_argument("folders", nargs="*", help="输入图像文件夹")
    parser.add_argument("-c", "--config", help="YAML 配置（batch_flow.yaml）")
    args = parser.parse_args()

    if not args.config:
        parser.error("请使用 --config batch_flow.yaml")

    cfg_path = Path(args.config).expanduser()
    if not cfg_path.is_file():
        parser.error(f"找不到配置: {cfg_path}")

    extra = [Path(p).expanduser() for p in args.folders]
    settings = settings_from_yaml(load_yaml_config(cfg_path), extra)
    print(f"已加载: {cfg_path.resolve()}")

    if settings.output_root:
        settings.output_root.mkdir(parents=True, exist_ok=True)

    if settings.mode == "folders":
        seen = set()
        for d in settings.folders:
            key = d.resolve()
            if key in seen:
                continue
            seen.add(key)
            if not d.is_dir():
                print(f"错误: 不是目录: {d}", file=sys.stderr)
                return 1

    dis = create_dis_flow(
        style=settings.dis_style,
        finest_scale=settings.finest_scale,
        patch_size=settings.patch_size,
        patch_stride=settings.patch_stride,
        gradient_descent_iterations=settings.gradient_descent_iterations,
        variational_refinement_iterations=settings.variational_refinement_iterations,
        variational_refinement_alpha=settings.variational_refinement_alpha,
        variational_refinement_delta=settings.variational_refinement_delta,
        variational_refinement_gamma=settings.variational_refinement_gamma,
    )
    print(f"DIS style={settings.dis_style} | mode={settings.mode}")
    if settings.mode == "i0_i1":
        jobs = list_i0_i1_jobs(settings)
        for job in jobs:
            print(f"数据集: {job.i0_dir.parent.name} | I0={job.i0_dir} | I1={job.i1_dir}")
        print(f"输出: {settings.output_subdir}/ (*.npz)")
    elif settings.reference == "origin0":
        print(
            f"基准图: {settings.reference_name} | "
            f"输出: {settings.output_subdir}/ （与图像文件夹同级） (*.npz)"
        )
    if settings.resize:
        print(f"resize={settings.resize[0]}x{settings.resize[1]}")
    if settings.save_npz:
        print(f"npz_save_mode={settings.npz_save_mode}")

    total_ok = total_fail = total_skip = 0

    if settings.mode == "i0_i1":
        jobs = list_i0_i1_jobs(settings)
        n_dirs = len(jobs)
        for dir_idx, job in enumerate(jobs, start=1):
            if n_dirs > 1:
                print(f"\n######## 数据集 [{dir_idx}/{n_dirs}] {job.i0_dir.parent} ########")
            pairs = collect_i0_i1_pairs(job.i0_dir, job.i1_dir, settings)
            ok, fail, skip = process_i0_i1_pairs(
                pairs, job.output_dir.resolve(), dis, settings,
            )
            total_ok += ok
            total_fail += fail
            total_skip += skip
    else:
        seen = set()
        input_dirs: List[Path] = []
        for d in settings.folders:
            key = d.resolve()
            if key in seen:
                continue
            seen.add(key)
            input_dirs.append(d)

        for d in input_dirs:
            if not d.is_dir():
                print(f"错误: 不是目录: {d}", file=sys.stderr)
                return 1

        n_dirs = len(input_dirs)
        for dir_idx, input_dir in enumerate(input_dirs, start=1):
            if n_dirs > 1:
                print(f"\n######## 文件夹 [{dir_idx}/{n_dirs}] ########")
            out_dir = resolve_output_dir(input_dir.resolve(), settings)
            ok, fail, skip = process_folder(input_dir.resolve(), out_dir.resolve(), dis, settings)
            total_ok += ok
            total_fail += fail
            total_skip += skip

    print(
        f"\n全部结束: 成功 {total_ok} | 失败 {total_fail} | 跳过 {total_skip} | "
        f"{n_dirs} 个任务"
    )
    return 1 if total_fail else 0


if __name__ == "__main__":
    sys.exit(main())
