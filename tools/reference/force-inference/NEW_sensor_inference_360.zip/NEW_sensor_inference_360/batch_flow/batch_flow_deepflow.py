#!/usr/bin/env python3
"""
批量 DeepFlow 光流（算法来自 /home/xinzhi/桌面/optiflow）。

与 batch_flow.py（DIS）并存；输出目录默认 deep_flow_Optical_Flow/。

用法:
  python batch_flow/batch_flow_deepflow.py --config batch_flow/batch_flow_deepflow_folders.yaml
"""

from __future__ import annotations

import argparse
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, List, Optional, Tuple

import cv2
import numpy as np

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from optical_flow_deepflow import compute_deepflow, create_deepflow, flow_to_polar_int16
from optical_flow_dis import to_gray

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif", ".webp"}


def parse_size(text: str) -> Tuple[int, int]:
    w, h = text.lower().replace(" ", "").split("x")
    return int(w), int(h)


def load_yaml_config(path: Path) -> dict[str, Any]:
    try:
        import yaml
    except ImportError as e:
        raise SystemExit("读取 YAML 需要 PyYAML: pip install pyyaml") from e
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SystemExit(f"YAML 根节点必须是字典: {path}")
    return data


def iter_images(root: Path, recursive: bool) -> List[Path]:
    if recursive:
        paths = sorted(p for p in root.rglob("*") if p.is_file())
    else:
        paths = sorted(p for p in root.iterdir() if p.is_file())
    return [p for p in paths if p.suffix.lower() in IMAGE_EXTENSIONS]


def find_reference_image(input_dir: Path, ref_name: str) -> Optional[Path]:
    target = ref_name.lower()
    for p in iter_images(input_dir, recursive=False):
        if p.name.lower() == target:
            return p
    return None


@dataclass
class DeepFlowSettings:
    folders: List[Path]
    output_subdir: str
    reference_name: str
    resize: Optional[Tuple[int, int]]
    blur_ksize: int
    deepflow_scale: float
    use_clahe: bool
    save_npz: bool
    npz_save_mode: str
    skip_existing: bool
    recursive: bool
    flow_filename_prefix: str
    flow_filename_strip_prefix: str
    flow_filename_suffix: str


def settings_from_yaml(cfg: dict[str, Any], extra: List[Path]) -> DeepFlowSettings:
    raw = cfg.get("folders") or []
    folders: List[Path] = []
    for item in raw:
        if isinstance(item, str):
            folders.append(Path(item).expanduser())
        elif isinstance(item, dict) and "path" in item:
            folders.append(Path(str(item["path"])).expanduser())
        else:
            raise SystemExit(f"folders 项格式错误: {item!r}")
    folders.extend(extra)
    if not folders:
        raise SystemExit("需要配置 folders")

    resize_raw = cfg.get("resize", "640x360")
    resize = parse_size(str(resize_raw)) if resize_raw else None
    npz_mode = str(cfg.get("npz_save_mode", "float16")).lower()
    if npz_mode not in ("float16", "polar", "full"):
        raise SystemExit("npz_save_mode 只能是 float16 | polar | full")

    return DeepFlowSettings(
        folders=folders,
        output_subdir=str(cfg.get("output_subdir", "deep_flow_Optical_Flow")),
        reference_name=str(cfg.get("reference_name", "Origin0.jpg")),
        resize=resize,
        blur_ksize=int(cfg.get("blur_ksize", 0)),
        deepflow_scale=float(cfg.get("deepflow_scale", 0.35)),
        use_clahe=bool(cfg.get("use_clahe", True)),
        save_npz=bool(cfg.get("save_npz", True)),
        npz_save_mode=npz_mode,
        skip_existing=bool(cfg.get("skip_existing", False)),
        recursive=bool(cfg.get("recursive", False)),
        flow_filename_prefix=str(cfg.get("flow_filename_prefix", "deep_flow_OpticalFlow")),
        flow_filename_strip_prefix=str(cfg.get("flow_filename_strip_prefix", "O_Image")),
        flow_filename_suffix=str(cfg.get("flow_filename_suffix", "")),
    )


def resolve_output_dir(input_dir: Path, settings: DeepFlowSettings) -> Path:
    return input_dir.parent / settings.output_subdir


def flow_npz_stem(image_stem: str, settings: DeepFlowSettings) -> str:
    stem = image_stem
    pfx = settings.flow_filename_strip_prefix
    if pfx and stem.startswith(pfx):
        stem = stem[len(pfx):]
    return f"{settings.flow_filename_prefix}{stem}{settings.flow_filename_suffix}"


def resize_if_needed(frame: np.ndarray, size: Optional[Tuple[int, int]]) -> np.ndarray:
    if size is None:
        return frame
    w, h = size
    if frame.shape[1] == w and frame.shape[0] == h:
        return frame
    return cv2.resize(frame, (w, h))


def save_flow_npz(
    output_dir: Path,
    stem: str,
    flow: np.ndarray,
    settings: DeepFlowSettings,
) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / f"{stem}.npz"
    if settings.npz_save_mode == "float16":
        np.savez_compressed(out_path, flow=flow.astype(np.float16))
    elif settings.npz_save_mode == "polar":
        np.savez_compressed(out_path, polar=flow_to_polar_int16(flow).astype(np.int16))
    else:
        np.savez_compressed(
            out_path,
            flow=flow.astype(np.float32),
            polar=flow_to_polar_int16(flow),
        )


def process_folder(
    input_dir: Path,
    output_dir: Path,
    algo,
    settings: DeepFlowSettings,
) -> Tuple[int, int, int]:
    ref_path = find_reference_image(input_dir, settings.reference_name)
    if ref_path is None:
        print(f"[跳过] 未找到基准图 {settings.reference_name}: {input_dir}")
        return 0, 0, 0

    ref_bgr = cv2.imread(str(ref_path))
    if ref_bgr is None:
        print(f"[跳过] 无法读取基准图: {ref_path}")
        return 0, 1, 0
    ref_bgr = resize_if_needed(ref_bgr, settings.resize)
    ref_gray = to_gray(ref_bgr, settings.blur_ksize)

    targets = [
        p for p in iter_images(input_dir, settings.recursive)
        if p.resolve() != ref_path.resolve()
    ]
    if not targets:
        print(f"[跳过] 除基准外无其它图像: {input_dir}")
        return 0, 0, 0

    output_dir.mkdir(parents=True, exist_ok=True)
    ok = fail = skip = 0
    total = len(targets)
    print(f"\n=== {input_dir} -> {output_dir} (DeepFlow, {total} 张) ===")

    t0 = time.time()
    for i, cur_path in enumerate(targets, 1):
        out_stem = flow_npz_stem(cur_path.stem, settings)
        out_file = output_dir / f"{out_stem}.npz"
        if settings.skip_existing and out_file.is_file():
            skip += 1
            continue

        cur_bgr = cv2.imread(str(cur_path))
        if cur_bgr is None:
            fail += 1
            continue
        cur_bgr = resize_if_needed(cur_bgr, settings.resize)
        cur_gray = to_gray(cur_bgr, settings.blur_ksize)

        try:
            flow = compute_deepflow(
                ref_gray,
                cur_gray,
                algo,
                scale=settings.deepflow_scale,
                use_clahe=settings.use_clahe,
            )
            if settings.save_npz:
                save_flow_npz(output_dir, out_stem, flow, settings)
            ok += 1
        except Exception as e:
            fail += 1
            print(f"  DeepFlow 失败 {cur_path.name}: {e}")

        if i % 10 == 0 or i == total:
            elapsed = time.time() - t0
            rate = i / elapsed if elapsed > 0 else 0
            print(f"\r  进度 {i}/{total} ({rate:.2f} 张/s)", end="", flush=True)

    print(f"\n  完成: 成功 {ok} | 失败 {fail} | 跳过 {skip} / {total}")
    return ok, fail, skip


def main() -> int:
    parser = argparse.ArgumentParser(description="批量 DeepFlow 光流（相对 Origin0.jpg）")
    parser.add_argument("folders", nargs="*", help="输入图像文件夹（可覆盖 YAML）")
    parser.add_argument("-c", "--config", required=True, help="YAML 配置")
    args = parser.parse_args()

    cfg_path = Path(args.config).expanduser()
    if not cfg_path.is_file():
        parser.error(f"找不到配置: {cfg_path}")

    extra = [Path(p).expanduser() for p in args.folders]
    settings = settings_from_yaml(load_yaml_config(cfg_path), extra)
    print(f"已加载: {cfg_path.resolve()}")

    algo = create_deepflow()
    print(f"算法: DeepFlow | scale={settings.deepflow_scale} | clahe={settings.use_clahe}")
    print(f"输出: {settings.output_subdir}/")
    print(f"文件名前缀: {settings.flow_filename_prefix}")
    if settings.resize:
        print(f"resize={settings.resize[0]}x{settings.resize[1]}")

    total_ok = total_fail = total_skip = 0
    seen = set()
    for input_dir in settings.folders:
        key = input_dir.resolve()
        if key in seen:
            continue
        seen.add(key)
        if not input_dir.is_dir():
            print(f"错误: 不是目录: {input_dir}", file=sys.stderr)
            return 1
        ok, fail, skip = process_folder(
            input_dir,
            resolve_output_dir(input_dir, settings),
            algo,
            settings,
        )
        total_ok += ok
        total_fail += fail
        total_skip += skip

    print(f"\n全部完成: 成功 {total_ok} | 失败 {total_fail} | 跳过 {total_skip}")
    return 1 if total_fail else 0


if __name__ == "__main__":
    sys.exit(main())
