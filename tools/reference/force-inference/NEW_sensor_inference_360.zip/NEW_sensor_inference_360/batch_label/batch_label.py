
import os
import re
import cv2
import numpy as np
import shutil  # 用于删除文件夹树
from tqdm import tqdm
import matplotlib
import matplotlib.pyplot as plt

# 强制使用 Agg 后端以在无界面环境下保存图片
matplotlib.use('Agg')
# ==========================================
# 1. 配置与路径
# ==========================================
BASE_DIR = "/home/xinzhi/桌面/Dataset0610_360"
SENSOR_DIRS = ["N2", "N6", "N9", "N10", "N11", "N12", "N21", "N22", "N23"]

GRID_ORDER_REVERSED = True  # True: 从右下到左上； False: 从左上到右下

# 网格划分参数
GRID_COLS = 8  # 网格列数
GRID_ROWS = 4  # 网格行数

CONTACT_RADIUS = 80.0
FLOW_THRESHOLD = 1  # 光流滤波阈值（像素位移量），低于此值的噪声将被归零
SAVE_VISUALIZATION = True


# ==========================================
# 2. 辅助函数
# ==========================================

def init_dis_flow(finest_scale=2, patch_size=4, patch_stride=2):
    """初始化DIS光流计算器"""
    dis_flow = cv2.DISOpticalFlow_create()
    dis_flow.setFinestScale(finest_scale)
    dis_flow.setPatchSize(patch_size)
    dis_flow.setPatchStride(patch_stride)
    dis_flow.setGradientDescentIterations(25)
    dis_flow.setVariationalRefinementIterations(5)
    dis_flow.setVariationalRefinementAlpha(20.0)
    dis_flow.setVariationalRefinementDelta(5.0)
    dis_flow.setVariationalRefinementGamma(10.0)
    return dis_flow


def draw_arrows(height, width, u, v, step=16, scale=1.0, color=(0, 255, 0), bg_color=(255, 255, 255), base_img=None,
                mask=None):
    """绘制矢量箭头"""
    if base_img is not None:
        img = base_img.copy()
    else:
        img = np.ones((height, width, 3), dtype=np.uint8) * np.array(bg_color, dtype=np.uint8)

    y, x = np.mgrid[step // 2:height:step, step // 2:width:step].reshape(2, -1).astype(int)
    u_sub, v_sub = u[y, x] * scale, v[y, x] * scale

    if mask is not None:
        mask_sub = mask[y, x]
    else:
        mask_sub = np.ones_like(u_sub, dtype=bool)

    for x1, y1, du, dv, valid in zip(x, y, u_sub, v_sub, mask_sub):
        if not valid:
            continue

        x2, y2 = int(x1 + du), int(y1 + dv)
        if abs(du) > 0.1 or abs(dv) > 0.1:
            cv2.arrowedLine(img, (x1, y1), (x2, y2), color, 1, tipLength=0.3)
            cv2.circle(img, (x1, y1), 2, color, -1)
    return img


def arrow_step_for_size(width, height, base_step=16):
    """按分辨率缩放光流可视化箭头步长"""
    return max(base_step, int(round(base_step * max(width / 640, height / 480))))


# ==========================================
# 3. 主处理流程
# ==========================================

def process_sensor(sensor_dir):
    """处理单个传感器目录，生成 Force_Map"""
    sensor_name = os.path.basename(sensor_dir)
    image_dir = os.path.join(sensor_dir, "Original_Images_post")
    label_dir = os.path.join(sensor_dir, "Force_Vector")
    output_npy_dir = os.path.join(sensor_dir, "Force_Map")
    output_vis_dir = os.path.join(sensor_dir, "output_vis")
    output_flow_vis_dir = os.path.join(sensor_dir, "output_flow_vis")
    reference_frame = os.path.join(image_dir, "Origin0.jpg")

    print(f"\n========== 处理 {sensor_name} ==========")
    if not os.path.isdir(image_dir):
        print(f"跳过：缺少 Original_Images -> {image_dir}")
        return
    if not os.path.isdir(label_dir):
        print(f"跳过：缺少 Force_Vector -> {label_dir}")
        return
    if not os.path.exists(reference_frame):
        print(f"跳过：缺少参考帧 -> {reference_frame}")
        return

    print("参考帧存在：", True)
    print("图像数量：", len([f for f in os.listdir(image_dir) if f.lower().endswith(('.jpg', '.png'))]))

    for dir_path in [output_npy_dir, output_vis_dir, output_flow_vis_dir]:
        if os.path.exists(dir_path):
            shutil.rmtree(dir_path)
        os.makedirs(dir_path, exist_ok=True)

    ref_bgr = cv2.imdecode(np.fromfile(reference_frame, dtype=np.uint8), cv2.IMREAD_COLOR)
    if ref_bgr is None:
        print(f"无法读取参考帧: {reference_frame}")
        return
    pre_gray = cv2.cvtColor(ref_bgr, cv2.COLOR_BGR2GRAY)
    height, width = pre_gray.shape
    vis_arrow_step = arrow_step_for_size(width, height)

    dis_optical_flow = init_dis_flow()
    files = sorted([f for f in os.listdir(image_dir) if f.lower().endswith(('.jpg', '.png'))])
    saved = 0
    skipped_no_label = 0

    for filename in tqdm(files, desc=f"{sensor_name}"):
        img_path = os.path.join(image_dir, filename)
        base_name = os.path.splitext(filename)[0]

        if base_name == "Origin0":
            continue

        label_name = base_name.replace("O_Image", "F_Vector", 1) if "O_Image" in base_name else base_name
        label_name += ".npz"
        label_path = os.path.join(label_dir, label_name)

        if not os.path.exists(label_path):
            skipped_no_label += 1
            continue

        force_data = np.load(label_path)["data"]
        target_f = [force_data[1], -force_data[0], force_data[2]]

        curr_bgr = cv2.imdecode(np.fromfile(img_path, dtype=np.uint8), cv2.IMREAD_COLOR)
        curr_gray = cv2.cvtColor(curr_bgr, cv2.COLOR_BGR2GRAY)

        flow_DIS = dis_optical_flow.calc(pre_gray, curr_gray, None)
        flow_u, flow_v = flow_DIS[..., 0], flow_DIS[..., 1]

        flow_mag = np.sqrt(flow_u ** 2 + flow_v ** 2)
        valid_flow_mask = flow_mag >= FLOW_THRESHOLD
        filtered_u = np.where(valid_flow_mask, flow_u, 0.0)
        filtered_v = np.where(valid_flow_mask, flow_v, 0.0)

        divergence = np.gradient(filtered_u, axis=1) + np.gradient(filtered_v, axis=0)
        mag_z = np.maximum(divergence, 0)
        smoothed_z = cv2.GaussianBlur(mag_z, (15, 15), 5.0)

        cx, cy = width / 2.0, height / 2.0

        try:
            match = re.search(r'-(\d+)-(-?[\d\.]+)-(-?[\d\.]+)-([a-zA-Z])$', base_name.strip())

            if match:
                grid_id = int(match.group(1))
                offset_x = float(match.group(3))
                offset_y = float(match.group(3))
                axis = match.group(4).lower()

                cell_w = width / GRID_COLS
                cell_h = height / GRID_ROWS

                grid_idx = grid_id - 1
                if GRID_ORDER_REVERSED:
                    r_idx = GRID_ROWS - 1 - (grid_idx // GRID_COLS)
                    c_idx = GRID_COLS - 1 - (grid_idx % GRID_COLS)
                else:
                    r_idx = grid_idx // GRID_COLS
                    c_idx = grid_idx % GRID_COLS
                base_cx = (c_idx + 0.5) * cell_w
                base_cy = (r_idx + 0.5) * cell_h

                cx, cy = base_cx - 30, base_cy + 5

                if axis == 'x':
                    cx -= offset_x * 35
                elif axis == 'y':
                    cy -= offset_y * 25
                else:
                    print(f"警告：{base_name} 坐标计算异常")

        except Exception as e:
            print(f"\n[警告] 解析 '{base_name}' 发生异常，已回退至默认中心。错误详情: {repr(e)}")

        dist_sq = (np.ogrid[:height, :width][1] - cx) ** 2 + (np.ogrid[:height, :width][0] - cy) ** 2
        hertz_mask = np.sqrt(np.maximum(0, 1.0 - dist_sq / (CONTACT_RADIUS ** 2)))

        s = np.sum(hertz_mask)
        final_maps = [(hertz_mask * (target_f[i] / s)) if s > 0 else np.zeros_like(hertz_mask) for i in range(3)]

        if SAVE_VISUALIZATION:
            flow_vis_img = draw_arrows(
                height, width, filtered_u, filtered_v, step=vis_arrow_step, scale=1.5,
                color=(0, 255, 0), base_img=curr_bgr
            )

            fig_flow, ax_flow = plt.subplots(1, 2, figsize=(14, 6))

            ax_flow[0].imshow(cv2.cvtColor(flow_vis_img, cv2.COLOR_BGR2RGB))
            ax_flow[0].plot(cx, cy, 'r+', markersize=15, markeredgewidth=2, label='Contact Center (Grid)')
            ax_flow[0].legend(loc='upper right', fontsize=10)
            ax_flow[0].set_title(f"Filtered Optical Flow Field (Thr={FLOW_THRESHOLD})")
            ax_flow[0].axis('off')

            div_max = np.max(smoothed_z) if np.max(smoothed_z) > 0 else 1.0
            im_div_sub = ax_flow[1].imshow(smoothed_z, cmap='jet', vmin=0, vmax=div_max)
            ax_flow[1].plot(cx, cy, 'k+', markersize=15, markeredgewidth=2, label='Contact Center (Grid)')
            plt.colorbar(im_div_sub, ax=ax_flow[1], fraction=0.046, pad=0.04)
            ax_flow[1].legend(loc='upper right', fontsize=10)
            ax_flow[1].set_title(f"Filtered Flow Divergence - {base_name}")
            ax_flow[1].axis('off')

            plt.tight_layout()
            plt.savefig(os.path.join(output_flow_vis_dir, f"Flow_Div_{base_name}.jpg"), dpi=120, bbox_inches='tight')
            plt.close(fig_flow)

            fig, axes = plt.subplots(1, 5, figsize=(26, 5))

            axes[0].imshow(cv2.cvtColor(flow_vis_img, cv2.COLOR_BGR2RGB))
            axes[0].plot(cx, cy, 'r+', markersize=15, markeredgewidth=2, label='Contact Center')
            axes[0].legend(loc='upper right', fontsize=8)
            axes[0].set_title("Filtered Optical Flow")
            axes[0].axis('off')

            im_div = axes[1].imshow(smoothed_z, cmap='jet', vmin=0, vmax=div_max)
            axes[1].plot(cx, cy, 'k+', markersize=15, markeredgewidth=2, label='Contact Center')
            plt.colorbar(im_div, ax=axes[1], fraction=0.046, pad=0.04)
            axes[1].set_title("Flow Divergence")
            axes[1].axis('off')

            titles = ['Force X', 'Force Y', 'Force Z']
            for i in range(3):
                ax_idx = i + 2
                v_lim = np.max(np.abs(final_maps[i])) if np.max(np.abs(final_maps[i])) > 0 else 1.0
                im_force = axes[ax_idx].imshow(final_maps[i], cmap='coolwarm', vmin=-v_lim, vmax=v_lim)
                axes[ax_idx].set_title(f"{titles[i]}\n(Target: {target_f[i]:.3f})")
                plt.colorbar(im_force, ax=axes[ax_idx], fraction=0.046, pad=0.04)
                if i == 2:
                    axes[ax_idx].plot(cx, cy, 'k+', markersize=15, markeredgewidth=2)
                axes[ax_idx].axis('off')

            plt.tight_layout()
            plt.savefig(os.path.join(output_vis_dir, f"Vis_{base_name}.jpg"), dpi=100, bbox_inches='tight')
            plt.close(fig)

        core_id = base_name.replace("O_Image", "")
        np.savez_compressed(os.path.join(output_npy_dir, f"ForceMap_{core_id}.npz"), data=np.stack(final_maps, axis=2))
        saved += 1

    print(f"{sensor_name} 完成：生成 {saved} 个 ForceMap，无标签跳过 {skipped_no_label} 张")
    print(f"输出目录：{output_npy_dir}")


def main(sensors=None, base_dir=None):
    names = sensors if sensors is not None else SENSOR_DIRS
    root = base_dir if base_dir is not None else BASE_DIR
    for name in names:
        process_sensor(os.path.join(root, name))


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="批量生成 Force_Map")
    parser.add_argument(
        "--sensors",
        nargs="*",
        default=None,
        help="指定传感器子目录（默认处理全部 SENSOR_DIRS）",
    )
    parser.add_argument("--base-dir", default=BASE_DIR, help="数据集根目录")
    cli = parser.parse_args()
    main(sensors=cli.sensors, base_dir=cli.base_dir)