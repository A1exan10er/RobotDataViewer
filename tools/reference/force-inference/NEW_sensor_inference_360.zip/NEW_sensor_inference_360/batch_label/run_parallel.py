#!/usr/bin/env python3
"""
并行运行 batch_label.py：每个传感器目录一个独立进程。

用法:
  python batch_label/run_parallel.py
  python batch_label/run_parallel.py -j 9
  python batch_label/run_parallel.py -j 4 --sensors N2 N6 N9
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
BATCH_LABEL = SCRIPT_DIR / "batch_label.py"
DEFAULT_BASE_DIR = "/home/xinzhi/桌面/Dataset0610_360"
DEFAULT_SENSORS = ["N2", "N6", "N9", "N10", "N11", "N12", "N21", "N22", "N23"]


def run_one_sensor(
    sensor: str,
    base_dir: str,
    python: str,
) -> tuple[str, int]:
    cmd = [
        python,
        str(BATCH_LABEL),
        "--base-dir",
        base_dir,
        "--sensors",
        sensor,
    ]
    proc = subprocess.run(cmd, cwd=SCRIPT_DIR.parent)
    return sensor, proc.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description="并行运行 batch_label（按传感器目录）")
    parser.add_argument(
        "-j",
        "--workers",
        type=int,
        default=min(9, os.cpu_count() or 1),
        help="同时运行的进程数（默认 min(9, CPU核数)）",
    )
    parser.add_argument("--base-dir", default=DEFAULT_BASE_DIR, help="数据集根目录")
    parser.add_argument(
        "--sensors",
        nargs="*",
        default=DEFAULT_SENSORS,
        help="要处理的传感器子目录列表",
    )
    args = parser.parse_args()

    sensors = list(args.sensors)
    workers = max(1, min(args.workers, len(sensors)))

    print(f"并行 batch_label: {len(sensors)} 个传感器, workers={workers}")
    print(f"BASE_DIR={args.base_dir}")
    print(f"脚本: {BATCH_LABEL}")
    print("传感器:", ", ".join(sensors))
    print()

    ok, fail = 0, 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(run_one_sensor, sensor, args.base_dir, sys.executable): sensor
            for sensor in sensors
        }
        for fut in as_completed(futures):
            sensor = futures[fut]
            try:
                name, code = fut.result()
            except Exception as exc:
                fail += 1
                print(f"[异常] {sensor}: {exc}", file=sys.stderr)
                continue
            if code == 0:
                ok += 1
                print(f"[完成] {name}")
            else:
                fail += 1
                print(f"[失败] {name} (exit {code})", file=sys.stderr)

    print(f"\n全部结束: 成功 {ok}, 失败 {fail} / {len(sensors)}")
    return 1 if fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
