import os
import glob
import time
import threading
import platform

os.environ.setdefault("QT_QPA_FONTDIR", "/usr/share/fonts/truetype/dejavu")
os.environ.setdefault("QT_LOGGING_RULES", "qt.qpa.fonts.warning=false")

import argparse
import sys
import cv2
import numpy as np

_BATCH_FLOW_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "batch_flow")
if _BATCH_FLOW_DIR not in sys.path:
    sys.path.insert(0, _BATCH_FLOW_DIR)
from optical_flow_dis import (
    compute_dis_flow,
    create_dis_flow,
    draw_flow_on_image,
    optical_flow_dis_original,
    to_gray,
)
from optical_flow_deepflow import compute_deepflow, create_deepflow

BATCH_FLOW_YAML = os.path.join(_BATCH_FLOW_DIR, "batch_flow_deepflow_live.yaml")
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


from niaokan import NiaokanCorrector, parse_res_arg


def load_birdview_corrector(width, height, flip_horizontal=False):
    """四点鸟瞰矫正（niaokan）；不做曲线/黑边填充。"""
    return NiaokanCorrector(
        width=width,
        height=height,
        save_size=FLOW_SIZE,
        flip_horizontal=flip_horizontal,
    )


IS_WINDOWS = platform.system() == "Windows"
IS_LINUX = platform.system() == "Linux"
DEFAULT_CAMERA = "0" if IS_WINDOWS else "/dev/video0"
LINUX_FOURCC_CANDIDATES = ("MJPG",)  # 只用 MJPG，避免掉到 YUYV

# 拉流直接用传感器分辨率；矫正后缩放到 FLOW_SIZE 做光流/推理
DEFAULT_CAPTURE_SIZE = (640, 360)
CAPTURE_FPS = 15
FLOW_SIZE = (640, 360)

BAD_FOURCC = frozenset({"YUY2", "UYVY", "NV12"})


def fourcc_to_str(code):
    value = int(code or 0)
    if value == 0:
        return "?"
    return "".join(chr((value >> (8 * i)) & 0xFF) for i in range(4)).strip("\x00") or "?"


def capture_backend_info(cap):
    backend = cap.getBackendName() if hasattr(cap, "getBackendName") else "?"
    fcc = fourcc_to_str(cap.get(cv2.CAP_PROP_FOURCC))
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    fps = cap.get(cv2.CAP_PROP_FPS) or 0
    return backend, fcc, w, h, fps


def read_camera_frame(cap, retries=3):
    for _ in range(retries):
        try:
            ok, frame = cap.read()
        except cv2.error:
            ok, frame = False, None
        if ok and frame is not None and frame.size > 0:
            return frame
        time.sleep(0.05)
    return None


def configure_capture(cap, width, height, fps, fourcc="MJPG"):
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    if fourcc:
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*fourcc))
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    if IS_LINUX and fps > 0:
        cap.set(cv2.CAP_PROP_FPS, fps)


def v4l2_sysfs_info(dev_path):
    base = os.path.basename(dev_path)
    sys_dir = os.path.join("/sys/class/video4linux", base)
    index = name = None
    index_file = os.path.join(sys_dir, "index")
    name_file = os.path.join(sys_dir, "name")
    if os.path.isfile(index_file):
        with open(index_file, encoding="utf-8") as f:
            index = int(f.read().strip())
    if os.path.isfile(name_file):
        with open(name_file, encoding="utf-8") as f:
            name = f.read().strip()
    return index, name


def is_likely_v4l2_capture_node(dev_path):
    """跳过 Ubuntu 上常见的 metadata 节点（如 /dev/video0 仅元数据）。"""
    if not os.path.exists(dev_path):
        return False
    index, name = v4l2_sysfs_info(dev_path)
    if name and "metadata" in name.lower():
        return False
    if index is not None and index != 0:
        return False
    return True


def print_camera_permission_hint():
    if not IS_LINUX:
        return
    devs = glob.glob("/dev/video*")
    if not devs:
        print("提示: 未发现 /dev/video*，请确认摄像头已插入并被系统识别 (lsusb / v4l2-ctl --list-devices)")
        return
    try:
        import grp
        video_gid = grp.getgrnam("video").gr_gid
        if video_gid not in os.getgroups():
            print("提示: 当前用户不在 video 组，可能无法访问摄像头。执行后重新登录:")
            print("  sudo usermod -aG video $USER")
    except (ImportError, KeyError):
        pass


def create_v4l2_capture(target):
    cap = cv2.VideoCapture(target, cv2.CAP_V4L2)
    if cap.isOpened():
        return cap
    cap.release()
    return None


def open_windows_camera(idx, width, height):
    """MSMF + MJPG，不设 FPS，读一帧即返回（快速打开）。"""
    cap = cv2.VideoCapture(int(idx), cv2.CAP_MSMF)
    if not cap.isOpened():
        cap.release()
        return None, None, 0, 0
    configure_capture(cap, width, height, 0)
    ok, frame = cap.read()
    if not ok or frame is None or frame.size == 0:
        cap.release()
        return None, None, 0, 0
    fh, fw = frame.shape[:2]
    return cap, frame, fw, fh


def read_latest_frame(cap, drain=2):
    """连续 read 丢弃旧帧，降低缓冲延迟。"""
    frame = None
    ok = False
    for _ in range(max(1, drain)):
        try:
            ok, frame = cap.read()
        except cv2.error:
            break
        if not ok or frame is None:
            break
    return ok, frame


class CaptureThread:
    """后台持续拉流，主线程只取最新帧。"""
    def __init__(self, cap, drain=2):
        self.cap = cap
        self.drain = drain
        self._lock = threading.Lock()
        self._frame = None
        self._seq = 0
        self._fps = 0.0
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self):
        count = 0
        t0 = time.perf_counter()
        while self._running:
            ok, frame = read_latest_frame(self.cap, self.drain)
            if ok and frame is not None:
                with self._lock:
                    self._frame = frame.copy()
                    self._seq += 1
                count += 1
            now = time.perf_counter()
            if now - t0 >= 1.0:
                with self._lock:
                    self._fps = count / max(now - t0, 1e-6)
                count = 0
                t0 = now

    def read(self, last_seq=-1):
        with self._lock:
            if self._frame is None or self._seq == last_seq:
                return False, None, last_seq, self._fps
            return True, self._frame, self._seq, self._fps

    def stop(self):
        self._running = False
        self._thread.join(timeout=2)


def normalize_camera_target(target):
    if isinstance(target, str):
        if target.isdigit():
            return int(target)
        if target.startswith("/dev/video"):
            try:
                return int(target.replace("/dev/video", ""))
            except ValueError:
                return target
    return target


def iter_linux_video_devices(preferred=None):
    seen = set()
    ordered = []
    if preferred is not None:
        if isinstance(preferred, int):
            ordered.append(f"/dev/video{preferred}")
        else:
            ordered.append(preferred)
    ordered.extend(sorted(glob.glob("/dev/video*")))
    for dev_path in ordered:
        key = os.path.realpath(dev_path) if os.path.exists(dev_path) else dev_path
        if key in seen:
            continue
        seen.add(key)
        if is_likely_v4l2_capture_node(dev_path):
            yield dev_path


def build_camera_targets(device):
    device = normalize_camera_target(device)
    targets = []
    if isinstance(device, int):
        targets.append(f"/dev/video{device}")
        targets.append(device)
    elif isinstance(device, str) and device.startswith("/dev/video"):
        targets.append(device)
        try:
            targets.append(int(device.replace("/dev/video", "")))
        except ValueError:
            pass
    else:
        targets.append(device)

    seen = set()
    unique = []
    for target in targets:
        key = str(target)
        if key not in seen:
            seen.add(key)
            unique.append(target)
    return unique


def setup_capture_linux(cap, width, height, fps):
    for fourcc in LINUX_FOURCC_CANDIDATES:
        configure_capture(cap, 640, 480, fps, fourcc)
        for _ in range(5):
            try:
                cap.read()
            except cv2.error:
                pass
            time.sleep(0.02)

        configure_capture(cap, width, height, fps, fourcc)
        frame = read_camera_frame(cap, retries=30)
        if frame is not None:
            h, w = frame.shape[:2]
            return frame, w, h
    return None, 0, 0


def try_open_linux_camera(device, width, height, fps):
    preferred = normalize_camera_target(device)
    tried = set()
    preferred_paths = list(iter_linux_video_devices(preferred))
    fallback_paths = [p for p in iter_linux_video_devices() if p not in preferred_paths]

    for dev_path in preferred_paths + fallback_paths:
        if dev_path in tried:
            continue
        tried.add(dev_path)

        cap = create_v4l2_capture(dev_path)
        if cap is None:
            continue

        bg_frame, cap_w, cap_h = setup_capture_linux(cap, width, height, fps)
        if bg_frame is not None:
            if str(device) != dev_path:
                print(f"使用摄像头: {dev_path}")
            return cap, bg_frame, cap_w, cap_h
        cap.release()

    return None, None, 0, 0


def open_camera(device, width=DEFAULT_CAPTURE_SIZE[0], height=DEFAULT_CAPTURE_SIZE[1], fps=CAPTURE_FPS):
    cap = None
    bg_frame = None
    cap_w = cap_h = 0

    if IS_WINDOWS:
        idx = normalize_camera_target(device)
        if not isinstance(idx, int):
            idx = 0
        cap, bg_frame, cap_w, cap_h = open_windows_camera(idx, width, height)
    else:
        cap, bg_frame, cap_w, cap_h = try_open_linux_camera(device, width, height, fps)

    if cap is None or bg_frame is None:
        print(f"无法打开 {width}x{height} 摄像头 (已尝试 MJPG/YUYV)")
        print_camera_permission_hint()
        return None, None, 0, 0

    backend, fcc, _, _, reported_fps = capture_backend_info(cap)
    fps_text = f" @ {reported_fps:.0f}fps" if reported_fps > 0 else ""
    print(
        f"拉流: {backend} | {fcc} | {cap_w}x{cap_h}{fps_text} -> "
        f"niaokan 鸟瞰 -> {FLOW_SIZE[0]}x{FLOW_SIZE[1]} (后台线程)"
    )
    return cap, bg_frame, cap_w, cap_h


def list_camera_devices():
    devices = []
    if IS_WINDOWS:
        for idx in range(10):
            cap, frame, w, h = open_windows_camera(
                idx, DEFAULT_CAPTURE_SIZE[0], DEFAULT_CAPTURE_SIZE[1]
            )
            if cap is None:
                continue
            cap.release()
            devices.append({"device": idx, "width": w, "height": h})
        return devices

    for dev_path in iter_linux_video_devices():
        cap = create_v4l2_capture(dev_path)
        if cap is None:
            continue
        frame, w, h = setup_capture_linux(
            cap, DEFAULT_CAPTURE_SIZE[0], DEFAULT_CAPTURE_SIZE[1], CAPTURE_FPS
        )[:3]
        cap.release()
        if frame is None:
            continue
        _, name = v4l2_sysfs_info(dev_path)
        devices.append({"device": dev_path, "width": w, "height": h, "name": name or ""})
    return devices


def setup_cv2_qt_fonts():
    font_dir = os.path.join(os.path.dirname(cv2.__file__), "qt", "fonts")
    if os.path.isdir(font_dir) and os.listdir(font_dir):
        return
    os.makedirs(font_dir, exist_ok=True)
    for src in glob.glob("/usr/share/fonts/truetype/dejavu/DejaVuSans*.ttf"):
        dst = os.path.join(font_dir, os.path.basename(src))
        if not os.path.exists(dst):
            try:
                os.symlink(src, dst)
            except OSError:
                pass


def correct_capture_frame(frame, corrector):
    """拉流帧 → niaokan 四点鸟瞰（截断右侧）→ FLOW_SIZE；无填充。"""
    return corrector.correct(frame)


def load_batch_flow_settings(config_path=BATCH_FLOW_YAML):
    try:
        import yaml
    except ImportError as e:
        raise SystemExit("光流配置需要 PyYAML: pip install pyyaml") from e

    with open(config_path, encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    resize = cfg.get("resize")
    if resize is not None:
        if isinstance(resize, str):
            rw, rh = resize.lower().replace(" ", "").split("x")
            yaml_size = (int(rw), int(rh))
        else:
            yaml_size = tuple(resize)
        if yaml_size != FLOW_SIZE:
            print(f"提示: 配置 resize={yaml_size[0]}x{yaml_size[1]}，光流固定使用 {FLOW_SIZE[0]}x{FLOW_SIZE[1]}")

    flow_algo = str(cfg.get("flow_algo", "deepflow")).lower().strip()
    if "deepflow_scale" in cfg:
        flow_algo = "deepflow"
    elif "dis_style" in cfg and flow_algo == "deepflow":
        flow_algo = "dis"

    return {
        "flow_algo": flow_algo,
        "dis_style": str(cfg.get("dis_style", "original")),
        "blur_ksize": int(cfg.get("blur_ksize", 0)),
        "resize": FLOW_SIZE,
        "arrow_step": int(cfg.get("arrow_step", 30)),
        "arrow_scale": float(cfg.get("arrow_scale", 10.0)),
        "deepflow_scale": float(cfg.get("deepflow_scale", 0.35)),
        "use_clahe": bool(cfg.get("use_clahe", True)),
        "finest_scale": int(cfg.get("finest_scale", 2)),
        "patch_size": int(cfg.get("patch_size", 4)),
        "patch_stride": int(cfg.get("patch_stride", 2)),
        "gradient_descent_iterations": int(cfg.get("gradient_descent_iterations", 25)),
        "variational_refinement_iterations": int(cfg.get("variational_refinement_iterations", 5)),
        "variational_refinement_alpha": float(cfg.get("variational_refinement_alpha", 20.0)),
        "variational_refinement_delta": float(cfg.get("variational_refinement_delta", 5.0)),
        "variational_refinement_gamma": float(cfg.get("variational_refinement_gamma", 10.0)),
    }


def create_dis_from_settings(settings):
    return create_dis_flow(
        style=settings["dis_style"],
        finest_scale=settings["finest_scale"],
        patch_size=settings["patch_size"],
        patch_stride=settings["patch_stride"],
        gradient_descent_iterations=settings["gradient_descent_iterations"],
        variational_refinement_iterations=settings["variational_refinement_iterations"],
        variational_refinement_alpha=settings["variational_refinement_alpha"],
        variational_refinement_delta=settings["variational_refinement_delta"],
        variational_refinement_gamma=settings["variational_refinement_gamma"],
    )


def create_flow_algo_from_settings(settings):
    if settings.get("flow_algo", "deepflow") == "deepflow":
        return create_deepflow()
    return create_dis_from_settings(settings)


def resize_to_flow(frame):
    tw, th = FLOW_SIZE
    h, w = frame.shape[:2]
    if w == tw and h == th:
        return frame
    return cv2.resize(frame, (tw, th))


def compute_batch_flow(ref_bgr, cur_bgr, algo, flow_settings):
    """在 FLOW_SIZE (640x360) 上计算光流（默认 DeepFlow，也可 DIS）。"""
    ref_bgr = resize_to_flow(ref_bgr)
    cur_bgr = resize_to_flow(cur_bgr)
    ref_gray = to_gray(ref_bgr, flow_settings["blur_ksize"])
    cur_gray = to_gray(cur_bgr, flow_settings["blur_ksize"])
    if flow_settings.get("flow_algo", "deepflow") == "deepflow":
        flow = compute_deepflow(
            ref_gray,
            cur_gray,
            algo,
            scale=float(flow_settings.get("deepflow_scale", 0.35)),
            use_clahe=bool(flow_settings.get("use_clahe", True)),
        )
    elif flow_settings.get("dis_style", "original") == "original":
        flow, _ = optical_flow_dis_original(ref_gray, cur_gray, algo)
    else:
        flow = compute_dis_flow(ref_gray, cur_gray, algo)
    return flow, cur_bgr, cur_gray


def normalize_fixed_scale(force_map, max_val=0.3):
    clipped = np.clip(force_map, 0, max_val)
    return ((clipped / max_val) * 255.0).astype(np.uint8)


def draw_arrows(
    height, width, u, v, step=16, scale=1.0, color=(0, 255, 0),
    bg_color=(255, 255, 255), base_img=None, mask=None, thickness=1,
):
    if base_img is not None:
        img = base_img.copy()
    else:
        img = np.ones((height, width, 3), dtype=np.uint8) * np.array(bg_color, dtype=np.uint8)

    y, x = np.mgrid[step // 2:height:step, step // 2:width:step].reshape(2, -1).astype(int)
    u_sub, v_sub = u[y, x] * scale, v[y, x] * scale
    mask_sub = mask[y, x] if mask is not None else np.ones_like(u_sub, dtype=bool)

    for x1, y1, du, dv, valid in zip(x, y, u_sub, v_sub, mask_sub):
        if not valid:
            continue
        x2, y2 = int(x1 + du), int(y1 + dv)
        if abs(du) > 0.5 or abs(dv) > 0.5:
            cv2.arrowedLine(img, (x1, y1), (x2, y2), color, thickness, tipLength=0.3)
            cv2.circle(img, (x1, y1), thickness + 1, color, -1)
    return img


def draw_force_plot(*hists, names=None, colors=None, width=640, sub_height=150):
    if names is None:
        if len(hists) == 2:
            names = ("Shear", "Fz")
        else:
            names = ("Fx", "Fy", "Fz")
    if colors is None:
        default_colors = ((0, 0, 255), (0, 255, 0), (255, 0, 0))
        colors = default_colors[:len(hists)]

    def draw_subplot(hist_data, name, color):
        img = np.ones((sub_height, width, 3), dtype=np.uint8) * 240
        cv2.rectangle(img, (0, 0), (width - 1, sub_height - 1), (200, 200, 200), 1)
        min_v, max_v = float(np.min(hist_data)), float(np.max(hist_data))
        pad = max((max_v - min_v) * 0.1, 1.0)
        min_v, max_v = min_v - pad, max_v + pad
        range_v = max_v - min_v

        def get_y(val):
            return int(sub_height - 10 - ((val - min_v) / range_v) * (sub_height - 20))

        pts_x = np.linspace(0, width, len(hist_data), dtype=int)
        pts_y = [get_y(v) for v in hist_data]
        pts = np.column_stack((pts_x, pts_y)).astype(np.int32)

        if min_v < 0 < max_v:
            y_zero = get_y(0)
            cv2.line(img, (0, y_zero), (width, y_zero), (180, 180, 180), 1, cv2.LINE_AA)

        cv2.polylines(img, [pts], False, color, 2, cv2.LINE_AA)
        current_value = float(hist_data[-1]) if len(hist_data) > 0 else 0.0
        cv2.putText(img, f"{name}: {current_value:.4f}", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2, cv2.LINE_AA)
        return img

    return np.vstack([
        draw_subplot(hist, name, color)
        for hist, name, color in zip(hists, names, colors)
    ])


from force_model import DEFAULT_MODEL_DIR, ForceNet, denorm_force, load_model_config
from image_diff import (
    build_model_input_tensor,
    compute_offset_diff,
    compute_relative_diff,
    diff_to_vis,
    make_diff_click_callback,
)


PIXEL_FORCE_MIN = 1e-5
VIS_FORCE_EPS = 5e-6
SEG_FZ_MIN_PIXELS = 1000  # Seg Fz 前景像素少于此值视为噪声，力置零


def build_deform_shape(flow, image_diff, region=None, flow_mag_min=1.5):
    """光流幅值 + |图像差| 生成接触形状；仅光流幅值 > flow_mag_min 的像素有效。"""
    u = flow[:, :, 0].astype(np.float32)
    v = flow[:, :, 1].astype(np.float32)
    flow_mag = np.sqrt(u * u + v * v)
    flow_gate = (flow_mag > float(flow_mag_min)).astype(np.float32)
    diff = np.abs(image_diff.astype(np.float32))

    flow_s = cv2.GaussianBlur(flow_mag, (9, 9), 2.0)
    diff_s = cv2.GaussianBlur(diff, (9, 9), 2.0)

    def norm01(x):
        peak = float(x.max())
        if peak <= 1e-8:
            return np.zeros_like(x, dtype=np.float32)
        return (x / peak).astype(np.float32)

    flow_n = norm01(flow_s)
    diff_n = norm01(diff_s)
    shape = (0.50 * flow_n * diff_n + 0.25 * flow_n + 0.25 * diff_n).astype(np.float32)
    shape = shape * flow_gate
    if region is not None:
        shape = shape * region.astype(np.float32)
    return shape, u, v, flow_gate.astype(bool)


def _apply_pixel_force_min(comp, gate, signed=False, min_val=PIXEL_FORCE_MIN):
    out = comp.astype(np.float32).copy()
    if signed:
        mag = np.abs(out)
        need = gate & (mag > 0) & (mag < float(min_val))
        out[need] = np.sign(out[need]) * float(min_val)
    else:
        need = gate & (out > 0) & (out < float(min_val))
        out[need] = float(min_val)
    return out


def _match_total(comp, target):
    """缩放分布图，使像素求和精确等于合力 target。"""
    out = comp.astype(np.float32)
    target = float(target)
    s = float(out.sum())
    if abs(target) <= 1e-12:
        return np.zeros_like(out)
    if abs(s) <= 1e-12:
        return out
    return (out * (target / s)).astype(np.float32)


def decompose_shear_to_fx_fy(u, v, shape, flow_gate, shear):
    """用光流加权方向，把剪切合力分解为带符号 Fx/Fy，满足 sqrt(Fx^2+Fy^2)=|shear|。"""
    w = np.maximum(shape.astype(np.float32), 0.0) * flow_gate.astype(np.float32)
    su = float((u.astype(np.float32) * w).sum())
    sv = float((v.astype(np.float32) * w).sum())
    mag = float(np.hypot(su, sv))
    s = abs(float(shear))
    if mag <= 1e-8 or s <= 1e-8:
        return 0.0, 0.0
    return s * su / mag, s * sv / mag


def build_force_map(flow, image_diff, force_phys, region=None, flow_mag_min=1.5, use_shear=True):
    """按光流+图像差形状把合力铺开；输出 (H,W,3)=[Fx,Fy,Fz]，且 sum 对齐合力。

    use_shear=True 时：模型给 (Shear,Fz)，按光流方向分解出带符号 Fx/Fy。
    返回 (force_map, support, force_xyz) ，force_xyz=[Fx,Fy,Fz]。
    """
    shape, u, v, flow_gate = build_deform_shape(
        flow, image_diff, region=region, flow_mag_min=flow_mag_min,
    )
    h, w = shape.shape
    zeros = np.zeros((h, w), dtype=np.float32)

    def share(weight, target, sign=None):
        weight = np.maximum(weight.astype(np.float32), 0.0) * flow_gate.astype(np.float32)
        total = float(weight.sum())
        scale = abs(float(target))
        if total <= 1e-8 or scale <= 1e-8:
            return zeros.copy()
        mag = weight * (scale / total)
        if sign is None:
            return mag.astype(np.float32)
        signed = (np.sign(sign) * mag).astype(np.float32)
        if abs(float(signed.sum())) <= 1e-8:
            return (np.sign(float(target)) * mag).astype(np.float32)
        return signed

    support = flow_gate & (shape > 0)
    force_phys = np.asarray(force_phys, dtype=np.float32).reshape(-1)

    if use_shear or force_phys.size == 2:
        fx, fy = decompose_shear_to_fx_fy(u, v, shape, flow_gate, force_phys[0])
        fz = float(force_phys[1])
        force_xyz = np.array([fx, fy, fz], dtype=np.float32)
    else:
        force_xyz = force_phys[:3].astype(np.float32)

    fx_map = share(np.abs(u) * shape, force_xyz[0], sign=u)
    fy_map = share(np.abs(v) * shape, force_xyz[1], sign=v)
    fz_map = share(shape, force_xyz[2])
    fx_map = _apply_pixel_force_min(fx_map, support, signed=True)
    fy_map = _apply_pixel_force_min(fy_map, support, signed=True)
    fz_map = _apply_pixel_force_min(fz_map, support, signed=False)
    fx_map = _match_total(fx_map, force_xyz[0])
    fy_map = _match_total(fy_map, force_xyz[1])
    fz_map = _match_total(fz_map, force_xyz[2])
    return np.stack([fx_map, fy_map, fz_map], axis=-1), support, force_xyz


def _append_colorbar(vis, vmin, vmax, signed=False):
    h, w = vis.shape[:2]
    bar_w, gap, label_w = 18, 6, 72
    if signed:
        t = np.linspace(1.0, -1.0, h, dtype=np.float32).reshape(h, 1)
        bar = np.zeros((h, bar_w, 3), dtype=np.uint8)
        bar[:, :, 2] = (np.clip(t, 0.0, 1.0) * 255.0).astype(np.uint8)
        bar[:, :, 0] = (np.clip(-t, 0.0, 1.0) * 255.0).astype(np.uint8)
    else:
        grad = np.linspace(255, 0, h, dtype=np.uint8).reshape(h, 1)
        bar = cv2.applyColorMap(np.repeat(grad, bar_w, axis=1), cv2.COLORMAP_JET)

    canvas = np.zeros((h, w + gap + bar_w + label_w, 3), dtype=np.uint8)
    canvas[:, :w] = vis
    canvas[:, w + gap:w + gap + bar_w] = bar
    x_txt = w + gap + bar_w + 4
    cv2.putText(canvas, f"{vmax:.4f}", (x_txt, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
    if signed:
        cv2.putText(canvas, "0", (x_txt, h // 2 + 4), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (200, 200, 200), 1, cv2.LINE_AA)
    cv2.putText(canvas, f"{vmin:.4f}", (x_txt, h - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA)
    return canvas


def draw_force_channel_map(comp, name, signed=False, total=None, bg=None, mask=None):
    """背景用 Fz Jet；不画箭头。小于 VIS_FORCE_EPS 的像素不显示。"""
    bg_data = np.maximum((bg if bg is not None else comp).astype(np.float32), 0.0)
    bg_data = np.where(bg_data >= VIS_FORCE_EPS, bg_data, 0.0).astype(np.float32)
    bg_peak = max(float(bg_data.max()), VIS_FORCE_EPS)
    vis = cv2.applyColorMap(normalize_fixed_scale(bg_data, max_val=bg_peak), cv2.COLORMAP_JET)

    data = comp.astype(np.float32)
    show = bg_data > 0
    if signed:
        show = show & (np.abs(data) >= VIS_FORCE_EPS)
        vmin, vmax = float(data.min()), float(data.max())
        hint = "bg=Fz  no arrows"
    else:
        show = show & (data >= VIS_FORCE_EPS)
        vmin, vmax = 0.0, float(np.maximum(data, 0.0).max())
        hint = "bg=Fz  blue=small red=large"
    if mask is not None:
        show = show & mask.astype(bool)
    vis[~show] = (vis[~show] * 0.15).astype(np.uint8)

    vis = _append_colorbar(vis, 0.0, bg_peak, signed=False)
    if total is None:
        title = f"{name}: px {vmin:.4f}~{vmax:.4f}"
    else:
        title = f"{name}: {float(total):.4f}  px {vmin:.4f}~{vmax:.4f}"
    cv2.putText(vis, title, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(vis, hint, (10, 48), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1, cv2.LINE_AA)
    return vis


def draw_force_overlay(force_map, force_xyz, shear=None, mask=None):
    """背景：Fz 像素力；文字显示 Shear/Fx/Fy/Fz。"""
    fx_map = force_map[:, :, 0].astype(np.float32)
    fy_map = force_map[:, :, 1].astype(np.float32)
    fz_map = np.maximum(force_map[:, :, 2].astype(np.float32), 0.0)
    significant = (
        (np.abs(fx_map) >= VIS_FORCE_EPS)
        | (np.abs(fy_map) >= VIS_FORCE_EPS)
        | (fz_map >= VIS_FORCE_EPS)
    )
    fz_disp = np.where(fz_map >= VIS_FORCE_EPS, fz_map, 0.0).astype(np.float32)
    show = (mask.astype(bool) if mask is not None else True) & significant & (fz_disp > 0)
    fz_peak = max(float(fz_disp.max()), VIS_FORCE_EPS)
    vis = cv2.applyColorMap(normalize_fixed_scale(fz_disp, max_val=fz_peak), cv2.COLORMAP_JET)
    vis[~show] = (vis[~show] * 0.15).astype(np.uint8)
    vis = _append_colorbar(vis, 0.0, fz_peak, signed=False)

    fx, fy, fz = [float(v) for v in force_xyz]
    shear_v = float(shear) if shear is not None else float(np.hypot(fx, fy))
    lines = (
        f"Shear: {shear_v:.4f}",
        f"Fx: {fx:.4f}",
        f"Fy: {fy:.4f}",
        f"Fz: {fz:.4f}",
    )
    for i, text in enumerate(lines):
        cv2.putText(vis, text, (10, 28 + i * 26), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.putText(vis, "red=large px force", (10, 140), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1, cv2.LINE_AA)
    cv2.putText(vis, "click: Fx/Fy/Fz", (10, 160), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1, cv2.LINE_AA)
    return vis


def _overlay_mouse_cb(event, x, y, flags, param):
    if event != cv2.EVENT_LBUTTONDOWN:
        return
    probe = param
    fm = probe.get("force_map")
    if fm is None:
        print(">>> 尚未有力图数据", flush=True)
        return
    h, w = fm.shape[:2]
    ow, oh = probe.get("overlay_wh", (w, h))
    title = probe.get("title", "4. Overlay: Dist Force")
    if ow > 0 and oh > 0 and not (0 <= x < ow and 0 <= y < oh):
        try:
            _, _, ww, wh = cv2.getWindowImageRect(title)
            if ww > 0 and wh > 0:
                x = int(round(x * ow / float(ww)))
                y = int(round(y * oh / float(wh)))
        except cv2.error:
            pass
    if not (0 <= x < w and 0 <= y < h):
        print(f">>> 点击在色条区域 (x={x}, y={y})", flush=True)
        return
    fx, fy, fz = float(fm[y, x, 0]), float(fm[y, x, 1]), float(fm[y, x, 2])
    probe["last_click"] = (x, y, fx, fy, fz)
    print(f">>> 像素 ({x}, {y})  Fx={fx:.8g}  Fy={fy:.8g}  Fz={fz:.8g}", flush=True)


def _draw_overlay_probe(overlay, probe):
    click = probe.get("last_click")
    if click is None:
        return overlay
    out = overlay.copy()
    x, y = int(click[0]), int(click[1])
    cv2.drawMarker(out, (x, y), (0, 255, 255), cv2.MARKER_CROSS, 16, 2)
    lines = (f"px ({x},{y})", f"Fx={click[2]:.6g}", f"Fy={click[3]:.6g}", f"Fz={click[4]:.6g}")
    tx = min(x + 12, out.shape[1] - 180)
    ty = max(y - 10, 70)
    for i, text in enumerate(lines):
        cv2.putText(out, text, (tx, ty + i * 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 2, cv2.LINE_AA)
    return out


def process_frame(
    frame, corrector, algo, net, bg_bgr, flow_settings, device,
    left_region, right_region,
    seg_threshold, baseline_norm,
    force_hists,
):
    corrected = correct_capture_frame(frame, corrector)
    flow, flow_bgr, gray = compute_batch_flow(bg_bgr, corrected, algo, flow_settings)
    if net.use_new_diff:
        diff = compute_offset_diff(
            bg_bgr, corrected, offset=net.diff_offset, diff_scale=net.diff_scale,
        )
    else:
        diff = compute_relative_diff(bg_bgr, corrected)
    input_tensor = build_model_input_tensor(
        flow, diff, device, require_diff=net.uses_image_diff,
    )

    force_phys, seg_probs, _ = net.predict_force_phys(input_tensor, baseline_norm)

    seg_fz = seg_probs[:, :, 0]
    seg_shear = seg_probs[:, :, 1]
    fz_pixel_count = int(np.count_nonzero(seg_fz >= seg_threshold))
    model_active = (
        ((seg_fz >= seg_threshold) | (seg_shear >= seg_threshold))
        & (left_region | right_region)
    )
    # 无激活区域，或 Seg Fz 像素过少（噪声）→ Fx/Fy/Fz 置零
    if (not np.any(model_active)) or (fz_pixel_count < SEG_FZ_MIN_PIXELS):
        force_phys = np.zeros(net.num_force_outputs, dtype=np.float32)

    force_map, deform_mask, force_xyz = build_force_map(
        flow, diff, force_phys,
        region=(left_region | right_region),
        use_shear=net.use_shear_magnitude,
    )
    # 曲线：Fx/Fy/Fz（Shear 模型时 Fx/Fy 由光流分解）
    plot_vals = force_xyz
    if len(force_hists) != 3:
        force_hists = [np.zeros(100) for _ in range(3)]
    for i, hist in enumerate(force_hists):
        hist = np.roll(hist, -1)
        hist[-1] = float(plot_vals[i])
        force_hists[i] = hist

    shear_model = float(force_phys[0]) if net.use_shear_magnitude else float(np.hypot(force_xyz[0], force_xyz[1]))
    overlay = draw_force_overlay(force_map, force_xyz, shear=shear_model, mask=deform_mask)
    flow_vis = draw_flow_on_image(
        flow_bgr.copy(), flow,
        step=flow_settings["arrow_step"],
        arrow_scale=flow_settings["arrow_scale"],
    )
    diff_vis = diff_to_vis(diff)

    fz_bg = force_map[:, :, 2]
    channel_maps = {
        "fx_map_vis": draw_force_channel_map(
            force_map[:, :, 0], "Fx", signed=True, total=force_xyz[0], bg=fz_bg, mask=deform_mask,
        ),
        "fy_map_vis": draw_force_channel_map(
            force_map[:, :, 1], "Fy", signed=True, total=force_xyz[1], bg=fz_bg, mask=deform_mask,
        ),
        "fz_map_vis": draw_force_channel_map(
            force_map[:, :, 2], "Fz", signed=False, total=force_xyz[2], bg=fz_bg, mask=deform_mask,
        ),
    }

    out = {
        "corrected": corrected,
        "overlay": overlay,
        "flow_vis": flow_vis,
        "diff_vis": diff_vis,
        "force_hists": force_hists,
        "gray": gray,
        "input_tensor": input_tensor,
        "flow_bgr": flow_bgr,
        "force_phys": force_phys,
        "force_xyz": force_xyz,
        "diff": diff,
        "force_map": force_map,
        "deform_mask": deform_mask,
        "flow": flow,
    }
    out.update(channel_maps)
    return out


def reset_baseline(net, bg_bgr_ref, baseline_norm, corrected, gray, input_tensor):
    import torch

    bg_bgr_ref[0] = corrected.copy()
    with torch.inference_mode():
        _, force_out = net(torch.zeros_like(input_tensor))
    baseline_norm[:] = force_out[0].float().cpu().numpy()


def main():
    p = argparse.ArgumentParser(description="触觉传感器实时推理（DeepFlow + Image_Diff + shear/fz）")
    p.add_argument("--camera", default=DEFAULT_CAMERA)
    p.add_argument("--fps", type=int, default=CAPTURE_FPS, help="采集帧率（默认 15）")
    p.add_argument(
        "--res",
        type=parse_res_arg,
        default=DEFAULT_CAPTURE_SIZE,
        help="拉流分辨率：640x360 或 640x480（默认 640x360）",
    )
    p.add_argument(
        "--flow-config",
        default=BATCH_FLOW_YAML,
        help="光流配置（默认 batch_flow_deepflow_live.yaml）",
    )
    p.add_argument("--flip-horizontal", action="store_true")
    p.add_argument("--lite", action="store_true", help="仅显示 Overlay")
    p.add_argument("--cpu", action="store_true")
    p.add_argument("--list-cameras", action="store_true")
    p.add_argument("--model-dir", default=DEFAULT_MODEL_DIR)
    args = p.parse_args()

    if args.list_cameras:
        devices = list_camera_devices()
        if not devices:
            print("未发现可用摄像头")
        else:
            for item in devices:
                name = f"  ({item['name']})" if item.get("name") else ""
                print(f"  {item['device']}{name}  {item['width']}x{item['height']}")
        return

    SEG_THRESHOLD = 0.1

    setup_cv2_qt_fonts()
    cv2.setUseOptimized(True)

    import torch

    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    model_dir = os.path.abspath(args.model_dir)
    flow_settings = load_batch_flow_settings(args.flow_config)
    algo = create_flow_algo_from_settings(flow_settings)
    rw, rh = FLOW_SIZE
    if flow_settings.get("flow_algo") == "deepflow":
        print(
            f"光流: DeepFlow | scale={flow_settings['deepflow_scale']} | "
            f"clahe={flow_settings['use_clahe']} | blur={flow_settings['blur_ksize']} | {rw}x{rh}"
        )
    else:
        print(
            f"光流: DIS/{flow_settings['dis_style']} | blur={flow_settings['blur_ksize']} | "
            f"{rw}x{rh} | arrow step={flow_settings['arrow_step']} scale={flow_settings['arrow_scale']}"
        )
    net = ForceNet(device, model_dir=model_dir)
    cfg = load_model_config(model_dir)
    print(
        f"模型: {os.path.basename(model_dir)} | in_channels={cfg['in_channels']} | "
        f"input={'flow+diff' if cfg.get('uses_image_diff') else 'flow'}"
    )
    if cfg["use_shear_magnitude"]:
        print(f"归一化: shear_max={cfg['shear_max']} fz_max={cfg['fz_max']} | Fx/Fy 由光流分解")
    else:
        print(
            f"归一化: fx_max={cfg['fx_max']} fy_max={cfg['fy_max']} fz_max={cfg['fz_max']}"
        )
    plot_names = ("Fx", "Fy", "Fz")

    cap_w_req, cap_h_req = args.res
    cap, bg_frame, cap_w, cap_h = open_camera(args.camera, cap_w_req, cap_h_req, args.fps)
    if cap is None:
        return

    grabber = CaptureThread(cap, drain=2 if IS_WINDOWS else 1)

    corrector = load_birdview_corrector(cap_w_req, cap_h_req, args.flip_horizontal)
    for line in corrector.info_lines():
        print(f"矫正: {line}")
    bg_corrected = correct_capture_frame(bg_frame, corrector)
    bg_bgr_ref = [bg_corrected]
    height, width = FLOW_SIZE[1], FLOW_SIZE[0]

    left_region = np.zeros((height, width), dtype=bool)
    left_region[:, :width // 2] = True
    right_region = ~left_region

    baseline_norm = net.zero_baseline()
    force_hists = [np.zeros(100) for _ in range(3)]  # Fx/Fy/Fz
    raw_flow_title = "0. Raw | Optical Flow"
    overlay_title = "4. Overlay: Dist Force"
    fx_title = "6. Fx Map"
    fy_title = "7. Fy Map"
    fz_title = "8. Fz Map"
    windows = [overlay_title] if args.lite else [
        raw_flow_title, "3. Image Diff",
        overlay_title, "5. Force Plot", fx_title, fy_title, fz_title,
    ]
    last_result = None
    diff_click_state = {"diff": None}
    overlay_probe = {
        "force_map": None,
        "last_click": None,
        "overlay_wh": (width, height),
        "title": overlay_title,
    }

    for name in windows:
        cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.setMouseCallback(overlay_title, _overlay_mouse_cb, overlay_probe)
    if not args.lite:
        cv2.setMouseCallback(
            "3. Image Diff",
            make_diff_click_callback(diff_click_state, "3. Image Diff"),
        )
        print("提示: Overlay 左键读像素 Fx/Fy/Fz；Shear 由模型输出，Fx/Fy 按光流分解")

    dev_name = torch.cuda.get_device_name(device) if device.type == "cuda" else "cpu"
    print(
        f"推理: {dev_name} | 拉流 {cap_w}x{cap_h} -> 鸟瞰 {corrector.out_w}x{corrector.out_h} "
        f"-> {width}x{height} | 按 q 退出, r 校零"
    )

    last_seq = -1
    loop_fps = 0.0
    loop_count = 0
    loop_t0 = time.perf_counter()
    cam_fps = 0.0
    logged_frame_shape = False

    try:
        while True:
            ret, frame, last_seq, cam_fps = grabber.read(last_seq)
            if not ret or frame is None:
                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), 27):
                    break
                continue

            if not logged_frame_shape:
                print(f"拉流帧尺寸: {frame.shape[1]}x{frame.shape[0]} (W x H), channels={frame.shape[2]}")
                logged_frame_shape = True

            result = process_frame(
                frame, corrector, algo, net, bg_bgr_ref[0], flow_settings, device,
                left_region, right_region,
                SEG_THRESHOLD, baseline_norm,
                force_hists,
            )
            force_hists = result["force_hists"]
            last_result = result
            diff_click_state["diff"] = result["diff"]
            overlay_probe["force_map"] = result["force_map"]
            oh, ow = result["overlay"].shape[:2]
            overlay_probe["overlay_wh"] = (ow, oh)
            overlay_vis = _draw_overlay_probe(result["overlay"], overlay_probe)
            loop_count += 1

            now = time.perf_counter()
            if now - loop_t0 >= 1.0:
                loop_fps = loop_count / max(now - loop_t0, 1e-6)
                loop_count = 0
                loop_t0 = now

            stats = f"cam {cam_fps:.0f} | loop {loop_fps:.0f} fps"

            if args.lite:
                overlay = overlay_vis.copy()
                cv2.putText(overlay, stats, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.imshow(overlay_title, overlay)
            else:
                raw = frame.copy()
                cv2.putText(raw, stats, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                raw_resized = cv2.resize(raw, (width, height), interpolation=cv2.INTER_AREA)
                raw_flow = np.hstack([raw_resized, result["flow_vis"]])
                cv2.imshow(raw_flow_title, raw_flow)
                cv2.imshow("3. Image Diff", result["diff_vis"])
                cv2.imshow(overlay_title, overlay_vis)
                cv2.imshow("5. Force Plot", draw_force_plot(*force_hists, names=plot_names))
                cv2.imshow(fx_title, result["fx_map_vis"])
                cv2.imshow(fy_title, result["fy_map_vis"])
                cv2.imshow(fz_title, result["fz_map_vis"])

            key = cv2.waitKey(1) & 0xFF
            if key in (ord("q"), 27):
                break
            if key == ord("r") and last_result is not None:
                reset_baseline(
                    net, bg_bgr_ref, baseline_norm,
                    last_result["corrected"], last_result["gray"], last_result["input_tensor"],
                )
                for hist in force_hists:
                    hist.fill(0)
                overlay_probe["last_click"] = None
                print(">>> 背景已重置，并完成模型基准校零 (Tare)。")
    finally:
        grabber.stop()
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
