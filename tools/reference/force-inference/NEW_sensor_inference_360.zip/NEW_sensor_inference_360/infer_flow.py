#!/usr/bin/env python3
"""离线推理：光流 + Image_Diff → 分割 + 物理合力 (shear, fz) 或 (fx, fy, fz)。

示例:
  python infer_flow.py flow.npz --diff Diff.npz
  python infer_flow.py flow.npz --diff Diff.npz --output result.json
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from force_model import DEFAULT_MODEL_DIR, ForceNet, load_model_config
from image_diff import build_model_input_tensor, load_diff_array


def load_flow(path: Path) -> np.ndarray:
    data = np.load(path)
    if hasattr(data, "files"):
        key = "flow" if "flow" in data.files else data.files[0]
        arr = data[key]
    else:
        arr = data
    if arr.ndim == 3 and arr.shape[0] in (2, 3) and arr.shape[0] < arr.shape[1]:
        arr = np.transpose(arr, (1, 2, 0))
    return arr.astype(np.float32)


def main() -> None:
    parser = argparse.ArgumentParser(description="光流(+Image_Diff) npz → 分割 + 合力推理")
    parser.add_argument("flow_npz", type=Path, help="光流文件 (.npz/.npy)，shape (H,W,2)")
    parser.add_argument(
        "--diff",
        type=Path,
        default=None,
        help="Image_Diff 文件 (.npz/.npy)，shape (H,W)；3 通道模型必填",
    )
    parser.add_argument("--model-dir", type=Path, default=DEFAULT_MODEL_DIR)
    parser.add_argument("--cpu", action="store_true")
    parser.add_argument("--output", type=Path, default=None, help="可选，保存 JSON 结果")
    args = parser.parse_args()

    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    model_dir = str(args.model_dir.resolve())
    cfg = load_model_config(model_dir)
    net = ForceNet(device, model_dir=model_dir)

    flow = load_flow(args.flow_npz)
    diff = None
    if args.diff is not None:
        diff = load_diff_array(str(args.diff), diff_scale=cfg.get("diff_scale"))
    elif cfg.get("uses_image_diff"):
        raise SystemExit("该模型需要 Image_Diff，请传入 --diff /path/to/Diff.npz")

    tensor = build_model_input_tensor(
        flow, diff, device, require_diff=bool(cfg.get("uses_image_diff")),
    )
    baseline = net.zero_baseline()
    force_phys, seg_probs, force_norm = net.predict_force_phys(tensor, baseline)

    if cfg["use_shear_magnitude"]:
        force_phys_dict = {
            "shear": float(force_phys[0]),
            "fz": float(force_phys[1]),
        }
        force_norm_dict = {
            "shear": float(force_norm[0]),
            "fz": float(force_norm[1]),
        }
    else:
        force_phys_dict = {
            "fx": float(force_phys[0]),
            "fy": float(force_phys[1]),
            "fz": float(force_phys[2]),
        }
        force_norm_dict = {
            "fx": float(force_norm[0]),
            "fy": float(force_norm[1]),
            "fz": float(force_norm[2]),
        }

    result = {
        "flow_file": str(args.flow_npz),
        "diff_file": str(args.diff) if args.diff is not None else None,
        "model_dir": model_dir,
        "in_channels": cfg["in_channels"],
        "use_shear_magnitude": cfg["use_shear_magnitude"],
        "force_phys": force_phys_dict,
        "force_norm": force_norm_dict,
        "seg_shape": list(seg_probs.shape),
    }
    print(json.dumps(result, indent=2, ensure_ascii=False))

    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        print(f"Saved: {args.output}")


if __name__ == "__main__":
    main()
