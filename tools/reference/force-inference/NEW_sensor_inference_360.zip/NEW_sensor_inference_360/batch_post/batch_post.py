#!/usr/bin/env python3
"""
批量透视校正：输入须 2560×1440 → warp 矫正 → 缩放回 2560×1440 保存。

示例:
  python batch_post/batch_post.py --config batch_post/batch_post.yaml
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, List, Optional, Tuple

import cv2
import numpy as np

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif", ".webp"}

# 标定分辨率与单应矩阵（勿改除非重标 H；也可通过 calib_file 加载 birdview.yaml）
DEFAULT_INPUT_SIZE = (2560, 1440)
DEFAULT_WARP_SIZE = (2154, 1523)
DEFAULT_HOMOGRAPHY = np.array([
    [1.9405102947673505, -0.029510258469070856, -689.17422205930859],
    [0.35748905956047777, 1.9090768045081032, -661.8776133515795],
    [0.00035771785981935869, 2.0370458982121464e-05, 1.0],
], dtype=np.float64)
DEFAULT_BORDER_VALUE = (255, 255, 255)
SCRIPT_DIR = Path(__file__).resolve().parent


def parse_size(text: str) -> Tuple[int, int]:
    w, h = text.lower().replace(" ", "").split("x")
    return int(w), int(h)


def normalize_frame_size(frame: np.ndarray, size: Tuple[int, int]) -> np.ndarray:
    w, h = size
    if frame.shape[1] != w or frame.shape[0] != h:
        return cv2.resize(frame, (w, h))
    return frame


def load_homography_yaml(path: Path) -> tuple[np.ndarray, Tuple[int, int], Tuple[int, int]]:
    """从 OpenCV 标定 yaml 加载 H、bird 尺寸、源图尺寸（与 cali.py 一致）。"""
    p = path.expanduser()
    if not p.is_absolute():
        p = SCRIPT_DIR / p
    if not p.is_file():
        raise SystemExit(f"标定文件不存在: {p}")
    fs = cv2.FileStorage(str(p), cv2.FILE_STORAGE_READ)
    H = fs.getNode("H").mat()
    bird_w = int(fs.getNode("bird_width").real())
    bird_h = int(fs.getNode("bird_height").real())
    src_w = int(fs.getNode("src_width").real())
    src_h = int(fs.getNode("src_height").real())
    fs.release()
    if H is None:
        raise SystemExit(f"yaml 里没有矩阵 H: {p}")
    if bird_w <= 0 or bird_h <= 0:
        bird_w, bird_h = DEFAULT_WARP_SIZE
    if src_w <= 0 or src_h <= 0:
        src_w, src_h = DEFAULT_INPUT_SIZE
    return np.asarray(H, dtype=np.float64), (bird_w, bird_h), (src_w, src_h)


def resize_to_size(frame: np.ndarray, size: Tuple[int, int]) -> np.ndarray:
    w, h = size
    if frame.shape[1] == w and frame.shape[0] == h:
        return frame
    return normalize_frame_size(frame, size)


def flip_horizontal(frame: np.ndarray) -> np.ndarray:
    """水平翻转（左右镜像），用于 N2 等传感器原始图方向校正。"""
    return cv2.flip(frame, 1)


@dataclass
class BirdViewCorrector:
    input_size: Tuple[int, int]
    warp_size: Tuple[int, int]
    save_size: Tuple[int, int]
    homography: np.ndarray
    border_value: Tuple[int, int, int] = DEFAULT_BORDER_VALUE
    flip_horizontal: bool = False

    def info_lines(self) -> List[str]:
        iw, ih = self.input_size
        ww, wh = self.warp_size
        sw, sh = self.save_size
        lines = [
            f"输入要求: {iw}x{ih}（须严格匹配）",
            f"warp 尺寸: {ww}x{wh}",
            f"保存尺寸: {sw}x{sh}（矫正后缩放回此尺寸）",
            f"边界填充: {self.border_value}",
        ]
        if self.flip_horizontal:
            lines.append("预处理: 水平翻转（左右对称）")
        return lines

    def correct(self, frame: np.ndarray) -> np.ndarray:
        h, w = frame.shape[:2]
        expected_w, expected_h = self.input_size
        if (w, h) != (expected_w, expected_h):
            raise ValueError(f"须 {expected_w}x{expected_h}，当前 {w}x{h}")

        if self.flip_horizontal:
            frame = flip_horizontal(frame)

        warp_w, warp_h = self.warp_size
        warped = cv2.warpPerspective(
            frame,
            self.homography,
            (warp_w, warp_h),
            flags=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=self.border_value,
        )
        return resize_to_size(warped, self.save_size)


def iter_images(root: Path, recursive: bool) -> Iterable[Path]:
    if recursive:
        paths = sorted(p for p in root.rglob("*") if p.is_file())
    else:
        paths = sorted(p for p in root.iterdir() if p.is_file())
    for p in paths:
        if p.suffix.lower() in IMAGE_EXTENSIONS:
            yield p


def resolve_output_dir(
    input_dir: Path,
    output_root: Path | None,
    suffix: str,
) -> Path:
    out_name = f"{input_dir.name}{suffix}"
    if output_root is not None:
        return output_root / out_name
    return input_dir.parent / out_name


def output_path_for(
    src: Path,
    input_dir: Path,
    out_dir: Path,
    same_name: bool,
) -> Path:
    rel = src.relative_to(input_dir)
    if same_name:
        return out_dir / rel
    return out_dir / rel.parent / f"{rel.stem}_corrected{rel.suffix}"


def save_image(path: Path, image: np.ndarray) -> bool:
    if cv2.imwrite(str(path), image):
        return True
    ok, buf = cv2.imencode(path.suffix, image)
    if not ok:
        return False
    path.write_bytes(buf.tobytes())
    return True


def process_folder(
    corrector: BirdViewCorrector,
    input_dir: Path,
    output_dir: Path,
    *,
    recursive: bool,
    same_name: bool,
    skip_existing: bool,
) -> Tuple[int, int, int]:
    output_dir.mkdir(parents=True, exist_ok=True)
    ok, fail, skip = 0, 0, 0

    images = list(iter_images(input_dir, recursive))
    if not images:
        print(f"[跳过] 无图像: {input_dir}")
        return 0, 0, 0

    print(f"\n=== {input_dir} -> {output_dir} ({len(images)} 张) ===")
    for src in images:
        dst = output_path_for(src, input_dir, output_dir, same_name)
        if skip_existing and dst.is_file():
            skip += 1
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)

        frame = cv2.imread(str(src))
        if frame is None:
            print(f"  无法读取: {src}")
            fail += 1
            continue
        try:
            out = corrector.correct(frame)
        except Exception as e:
            print(f"  校正失败 {src}: {e}")
            fail += 1
            continue
        if not save_image(dst, out):
            print(f"  写入失败: {dst}")
            fail += 1
            continue
        ok += 1

    print(f"  完成: 成功 {ok} | 失败 {fail} | 跳过已存在 {skip}")
    return ok, fail, skip


def load_yaml_config(path: Path) -> dict[str, Any]:
    try:
        import yaml
    except ImportError as e:
        raise SystemExit(
            "读取 YAML 需要 PyYAML: pip install pyyaml"
        ) from e
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise SystemExit(f"YAML 根节点必须是字典: {path}")
    return data


def _parse_size_field(value: Any, field: str, default: Tuple[int, int]) -> Tuple[int, int]:
    if value is None:
        return default
    return parse_size(str(value))


def _parse_homography(value: Any) -> np.ndarray:
    if value is None:
        return DEFAULT_HOMOGRAPHY.copy()
    rows = np.asarray(value, dtype=np.float64)
    if rows.shape != (3, 3):
        raise SystemExit(f"homography 必须是 3x3，当前 shape={rows.shape}")
    return rows


def _parse_border_value(value: Any) -> Tuple[int, int, int]:
    if value is None:
        return DEFAULT_BORDER_VALUE
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise SystemExit("border_value 必须是 [B, G, R] 三个整数")
    return int(value[0]), int(value[1]), int(value[2])


@dataclass
class FolderEntry:
    path: Path
    flip_horizontal: bool = False


@dataclass
class RunSettings:
    folders: List[FolderEntry]
    output_root: Optional[Path]
    suffix: str
    input_size: Tuple[int, int]
    warp_size: Tuple[int, int]
    save_size: Tuple[int, int]
    homography: np.ndarray
    border_value: Tuple[int, int, int]
    recursive: bool
    same_name: bool
    skip_existing: bool
    calib_file: Optional[Path] = None


def _apply_calib_file(
    calib_file: str | Path | None,
    input_size: Tuple[int, int],
    warp_size: Tuple[int, int],
    homography: np.ndarray,
) -> tuple[Tuple[int, int], Tuple[int, int], np.ndarray, Optional[Path]]:
    if not calib_file:
        return input_size, warp_size, homography, None
    path = Path(str(calib_file)).expanduser()
    H, bird_size, src_size = load_homography_yaml(path)
    return src_size, bird_size, H, path.resolve()


def parse_folder_entry(item: Any) -> FolderEntry:
    if isinstance(item, str):
        return FolderEntry(path=Path(item).expanduser())
    if isinstance(item, dict) and "path" in item:
        return FolderEntry(
            path=Path(str(item["path"])).expanduser(),
            flip_horizontal=bool(item.get("flip_horizontal", False)),
        )
    raise SystemExit(f"folders 项格式错误: {item!r}（应为路径字符串或 path: ...）")


def settings_from_yaml(cfg: dict[str, Any], extra_folders: List[Path]) -> RunSettings:
    raw_folders = cfg.get("folders") or []
    if not raw_folders and not extra_folders:
        raise SystemExit("YAML 中 folders 为空，请至少填一个路径")
    folders: List[FolderEntry] = [parse_folder_entry(item) for item in raw_folders]
    folders.extend(FolderEntry(path=p) for p in extra_folders)

    out_root = cfg.get("output_root")
    input_size = _parse_size_field(cfg.get("input_size"), "input_size", DEFAULT_INPUT_SIZE)
    warp_raw = cfg.get("warp_size", cfg.get("output_size"))
    warp_size = _parse_size_field(warp_raw, "warp_size", DEFAULT_WARP_SIZE)
    homography = _parse_homography(cfg.get("homography"))
    calib_raw = cfg.get("calib_file")
    input_size, warp_size, homography, calib_file = _apply_calib_file(
        calib_raw, input_size, warp_size, homography,
    )
    save_size = _parse_size_field(cfg.get("save_size"), "save_size", input_size)
    return RunSettings(
        folders=folders,
        output_root=Path(out_root).expanduser() if out_root else None,
        suffix=str(cfg.get("suffix", "_post")),
        input_size=input_size,
        warp_size=warp_size,
        save_size=save_size,
        homography=homography,
        border_value=_parse_border_value(cfg.get("border_value")),
        recursive=bool(cfg.get("recursive", False)),
        same_name=bool(cfg.get("same_name", False)),
        skip_existing=bool(cfg.get("skip_existing", False)),
        calib_file=calib_file,
    )


def settings_from_args(args: argparse.Namespace) -> RunSettings:
    folders = [FolderEntry(path=p, flip_horizontal=args.flip_horizontal) for p in collect_input_dirs(args)]
    input_size = parse_size(args.input_size)
    warp_size = parse_size(args.warp_size)
    homography = DEFAULT_HOMOGRAPHY.copy()
    input_size, warp_size, homography, calib_file = _apply_calib_file(
        args.calib, input_size, warp_size, homography,
    )
    return RunSettings(
        folders=folders,
        output_root=Path(args.output_root).expanduser() if args.output_root else None,
        suffix=args.suffix,
        input_size=input_size,
        warp_size=warp_size,
        save_size=parse_size(args.save_size) if args.save_size else input_size,
        homography=homography,
        border_value=DEFAULT_BORDER_VALUE,
        recursive=args.recursive,
        same_name=args.same_name,
        skip_existing=args.skip_existing,
        calib_file=calib_file,
    )


def load_folder_list(list_file: Path) -> List[Path]:
    paths: List[Path] = []
    for line in list_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        paths.append(Path(line).expanduser())
    return paths


def collect_input_dirs(args: argparse.Namespace) -> List[Path]:
    dirs: List[Path] = []
    if args.folders:
        dirs.extend(Path(p).expanduser() for p in args.folders)
    if args.list:
        dirs.extend(load_folder_list(Path(args.list).expanduser()))
    seen = set()
    unique: List[Path] = []
    for d in dirs:
        key = d.resolve()
        if key in seen:
            continue
        seen.add(key)
        unique.append(d)
    return unique


def build_corrector(settings: RunSettings, *, flip_horizontal: bool = False) -> BirdViewCorrector:
    return BirdViewCorrector(
        input_size=settings.input_size,
        warp_size=settings.warp_size,
        save_size=settings.save_size,
        homography=settings.homography,
        border_value=settings.border_value,
        flip_horizontal=flip_horizontal,
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="批量透视校正（2560×1440 输入 → 矫正 → 缩放回保存尺寸）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("folders", nargs="*", help="一个或多个输入图像文件夹")
    parser.add_argument("-c", "--config", type=str, default=None, help="YAML 配置文件（见 batch_post.yaml 示例）")
    parser.add_argument("--list", "-l", type=str, default=None, help="文本文件：每行一个文件夹路径（# 开头为注释）")
    parser.add_argument("-o", "--output-root", type=str, default=None, help="输出根目录；每个输入文件夹在其下建同名子目录")
    parser.add_argument("--suffix", default="_post", help="输出目录名为 输入文件夹名+此后缀（默认 _post，与输入同级）")
    parser.add_argument("--input-size", type=str, default="2560x1440", help="输入图像尺寸，须严格匹配（默认 2560x1440）")
    parser.add_argument("--warp-size", type=str, default="2154x1523", help="warpPerspective 画布尺寸（默认 2154x1523）")
    parser.add_argument(
        "--calib", type=str, default=None,
        help="OpenCV 标定 yaml（含 H、bird_width、bird_height），覆盖 homography/warp-size/input-size",
    )
    parser.add_argument("--save-size", type=str, default=None, help="矫正后保存尺寸，默认与 input-size 相同（2560x1440）")
    parser.add_argument("--recursive", "-r", action="store_true", help="递归处理子文件夹中的图像")
    parser.add_argument("--same-name", action="store_true", help="输出文件名与输入相同（仅目录结构镜像到输出路径）")
    parser.add_argument("--skip-existing", action="store_true", help="若输出文件已存在则跳过")
    parser.add_argument(
        "--flip-horizontal", action="store_true",
        help="矫正前先水平翻转（N2 等传感器左右对称处理）",
    )
    args = parser.parse_args()

    if args.config:
        cfg_path = Path(args.config).expanduser()
        if not cfg_path.is_file():
            parser.error(f"找不到配置文件: {cfg_path}")
        extra = [Path(p).expanduser() for p in args.folders]
        settings = settings_from_yaml(load_yaml_config(cfg_path), extra)
        print(f"已加载配置: {cfg_path.resolve()}")
    else:
        settings = settings_from_args(args)
        if not settings.folders:
            parser.error("请指定文件夹、--list、或 --config batch_post.yaml")

    seen = set()
    folder_entries: List[FolderEntry] = []
    for entry in settings.folders:
        key = entry.path.resolve()
        if key in seen:
            continue
        seen.add(key)
        folder_entries.append(entry)

    for entry in folder_entries:
        if not entry.path.is_dir():
            print(f"错误: 不是有效目录: {entry.path}", file=sys.stderr)
            return 1

    if settings.output_root:
        settings.output_root.mkdir(parents=True, exist_ok=True)

    print("校正参数:")
    if settings.calib_file:
        print(f"  标定文件: {settings.calib_file}")
    base_corrector = build_corrector(settings)
    for line in base_corrector.info_lines():
        print(f"  {line}")
    print(f"  待处理文件夹: {len(folder_entries)} 个")

    total_ok = total_fail = total_skip = 0
    for entry in folder_entries:
        input_dir = entry.path.resolve()
        corrector = build_corrector(settings, flip_horizontal=entry.flip_horizontal)
        out_dir = resolve_output_dir(
            input_dir, settings.output_root, settings.suffix,
        )
        flip_note = " [水平翻转]" if entry.flip_horizontal else ""
        print(f"\n>>> {input_dir.name}{flip_note}")
        ok, fail, skip = process_folder(
            corrector,
            input_dir,
            out_dir.resolve(),
            recursive=settings.recursive,
            same_name=settings.same_name,
            skip_existing=settings.skip_existing,
        )
        total_ok += ok
        total_fail += fail
        total_skip += skip

    print(
        f"\n全部结束: 成功 {total_ok} | 失败 {total_fail} | 跳过 {total_skip} | "
        f"共 {len(folder_entries)} 个文件夹"
    )
    return 1 if total_fail else 0


if __name__ == "__main__":
    sys.exit(main())
