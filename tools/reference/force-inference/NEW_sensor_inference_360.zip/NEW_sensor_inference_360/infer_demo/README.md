# infer_demo

## 功能

从相机图像估计触觉接触力。

流程：`1280×720` 原图 → 鸟瞰矫正 → DIS 光流 → PSPNet 推断。

输出：

- `force`：合力 `(Fx, Fy, Fz)`，单位 N
- `force_map`：逐像素力图，形状 `(360, 640, 3)`，通道为 Fx / Fy / Fz（压力）

可视化窗口：相机原图、矫正图、光流、压力+剪切 overlay、合力曲线。

## 使用方法

在本目录执行：

```bash
pip install -r requirements.txt
python demo.py
```

按 `q` 退出。按 `r` 重置背景 I0（清零光流与合力曲线）。

接入自己的循环：

```python
from infer import infer, process, show

processed = process(frame, False)          # True：更换 I0 并清零光流
force, force_map = infer(processed, cuda=True)
fx, fy, fz = force
fx_map = force_map[:, :, 0]
fy_map = force_map[:, :, 1]
fz_map = force_map[:, :, 2]

show(frame, processed, force, force_map)
```

## 要求

- 相机输出必须为 `1280×720` BGR，否则 `process` 会报错
- Python >= 3.9，依赖见 `requirements.txt`：`numpy>=1.26.4`、`opencv-python>=4.10.0.84`、`torch>=2.8.0`
- 有 CUDA 时 `infer(..., cuda=True)` 走 GPU，否则自动用 CPU
- 权重文件需存在：`infer/models/PSP_simulation_stage1_360.pt`
