"""原来的全部可视化：原图、矫正、光流、压力+剪切 overlay、合力曲线。"""
import cv2
import numpy as np

from .process import Processed

PRESSURE_MAX = 0.001
SHEAR_MAX = 0.0005


def _arrows(img, u, v, step, scale, color):
    h, w = u.shape
    ys, xs = np.mgrid[step // 2:h:step, step // 2:w:step]
    du, dv = u[ys, xs] * scale, v[ys, xs] * scale
    keep = (np.abs(du) > 0.5) | (np.abs(dv) > 0.5)
    for x, y, dx, dy in zip(xs[keep], ys[keep], du[keep], dv[keep]):
        p1 = (int(x), int(y))
        p2 = (int(x + dx), int(y + dy))
        cv2.arrowedLine(img, p1, p2, color, 1, tipLength=0.3)
    return img


def _overlay(force_map):
    p = np.clip(force_map[..., 2] / PRESSURE_MAX / 0.3 * 255, 0, 255).astype(np.uint8)
    vis = cv2.applyColorMap(p, cv2.COLORMAP_JET)
    return _arrows(vis, force_map[..., 0] / SHEAR_MAX, force_map[..., 1] / SHEAR_MAX, 16, 120.0, (255, 255, 255))


def _force_plot(hist, width=640, sub_h=150):
    img = np.full((sub_h * 3, width, 3), 240, np.uint8)
    names = ("Fx", "Fy", "Fz")
    colors = ((0, 0, 255), (0, 255, 0), (255, 0, 0))
    xs = np.linspace(0, width, hist.shape[0], dtype=np.int32)
    for i, (name, color) in enumerate(zip(names, colors)):
        y0 = i * sub_h
        slot = img[y0:y0 + sub_h]
        cv2.rectangle(slot, (0, 0), (width - 1, sub_h - 1), (200, 200, 200), 1)
        data = hist[:, i]
        min_v, max_v = float(data.min()), float(data.max())
        pad = max((max_v - min_v) * 0.1, 1.0)
        min_v, max_v = min_v - pad, max_v + pad
        ys = (sub_h - 10 - (data - min_v) / (max_v - min_v) * (sub_h - 20)).astype(np.int32)
        if min_v < 0 < max_v:
            yz = int(sub_h - 10 - (0 - min_v) / (max_v - min_v) * (sub_h - 20))
            cv2.line(slot, (0, yz), (width, yz), (180, 180, 180), 1, cv2.LINE_AA)
        cv2.polylines(slot, [np.column_stack((xs, ys))], False, color, 2, cv2.LINE_AA)
        cv2.putText(
            slot, f"{name}: {float(data[-1]):.4f}", (10, 25),
            cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2, cv2.LINE_AA,
        )
    return img


class Show:
    def __init__(self, history=100):
        self.hist = np.zeros((history, 3), np.float32)
        for name in (
            "0. Camera Raw",
            "1. Corrected",
            "2. Optical Flow",
            "4. Overlay: Pressure + Shear",
            "5. Force Plot",
        ):
            cv2.namedWindow(name, cv2.WINDOW_NORMAL)

    def __call__(self, frame, processed: Processed, force, force_map):
        self.hist[:-1] = self.hist[1:]
        self.hist[-1] = force
        overlay = _overlay(force_map)
        cv2.putText(
            overlay,
            f"Fx={force[0]:.4f}  Fy={force[1]:.4f}  Fz={force[2]:.4f}",
            (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2,
        )
        cv2.imshow("0. Camera Raw", frame)
        cv2.imshow("1. Corrected", processed.image)
        cv2.imshow("2. Optical Flow", _arrows(processed.image.copy(), processed.flow[..., 0], processed.flow[..., 1], 30, 10.0, (0, 255, 0)))
        cv2.imshow("4. Overlay: Pressure + Shear", overlay)
        cv2.imshow("5. Force Plot", _force_plot(self.hist))
        key = cv2.waitKey(1) & 0xFF
        if key == ord("r"):
            from .process import request_reset
            request_reset()
            self.hist.fill(0)
        return key


_vis = None


def show(frame, processed, force, force_map):
    global _vis
    if _vis is None:
        _vis = Show()
    return _vis(frame, processed, force, force_map)
