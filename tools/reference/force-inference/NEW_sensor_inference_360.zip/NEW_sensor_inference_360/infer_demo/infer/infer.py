"""输入: Processor 输出。输出: force (3,) 与 force_map (360, 640, 3)。"""
from __future__ import annotations

import importlib.util
import os

import numpy as np
import torch

from .process import FLOW_SIZE, Processed

_DIR = os.path.dirname(__file__)
WEIGHTS = os.path.join(_DIR, "models", "PSP_simulation_stage1_360.pt")
ARCH = os.path.join(_DIR, "models", "multitask_pspnet.py")

PRESSURE_MAX = 0.001
SHEAR_MAX = 0.0005
SEG_THRESHOLD = 0.01
PRESSURE_THRESH = 0.00001


def _load_model(device: torch.device):
    spec = importlib.util.spec_from_file_location("multitask_pspnet", ARCH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    net = module.MultiTaskPSPNet(in_channels=2, num_classes=2).to(device)
    try:
        weights = torch.load(WEIGHTS, map_location=device, weights_only=False)
    except TypeError:
        weights = torch.load(WEIGHTS, map_location=device)
    if isinstance(weights, dict) and "state_dict" in weights:
        weights = weights["state_dict"]
    net.load_state_dict(weights)
    net.eval()
    return net


class Infer:
    def __init__(self, cuda=True):
        if cuda and torch.cuda.is_available():
            device = "cuda"
        else:
            device = "cpu"
        self.device = torch.device(device)
        if self.device.type == "cuda":
            torch.backends.cudnn.benchmark = True
        self.model = _load_model(self.device)
        self.use_amp = self.device.type == "cuda"
        h, w = FLOW_SIZE[1], FLOW_SIZE[0]
        z = torch.zeros(1, 2, h, w, device=self.device)
        with torch.inference_mode():
            _, p, s = self._forward(z)
        self.baseline_p = p[0, 0].float()
        self.baseline_s = s[0, 0].float()

    def __call__(self, processed: Processed) -> tuple[np.ndarray, np.ndarray]:
        flow = np.ascontiguousarray(processed.flow.transpose(2, 0, 1))
        x = torch.from_numpy(flow).unsqueeze(0).to(self.device, non_blocking=True)
        with torch.inference_mode():
            seg, p_out, s_out = self._forward(x)
            pressure = (p_out[0, 0].float() - self.baseline_p).clamp(min=0)
            shear = (s_out[0, 0].float() - self.baseline_s).clamp(min=0)
            p_mask = (seg[0, 0] >= SEG_THRESHOLD) & (pressure >= PRESSURE_THRESH)
            s_mask = (seg[0, 1] >= SEG_THRESHOLD) & p_mask
            pressure = pressure * p_mask
            shear = shear * s_mask
            u, v = x[0, 0], x[0, 1]
            mag = (u * u + v * v).sqrt().clamp(min=1e-9)
            fx = u / mag * shear * SHEAR_MAX
            fy = v / mag * shear * SHEAR_MAX
            fz = pressure * PRESSURE_MAX
            force_map = torch.stack((fx, fy, fz), dim=-1)
            force = force_map.view(-1, 3).sum(0)
            out = torch.cat((force, force_map.reshape(-1)))
        out = out.float().cpu().numpy()
        return out[:3], out[3:].reshape(flow.shape[1], flow.shape[2], 3)

    def _forward(self, x):
        if self.use_amp:
            with torch.autocast(device_type="cuda", dtype=torch.float16):
                return self.model(x)
        return self.model(x)


_net = None


def infer(processed, cuda=True):
    global _net
    if _net is None:
        _net = Infer(cuda=cuda)
    return _net(processed)
