"""透视矫正：1280×720 一次 remap 到 640×360。"""
from dataclasses import dataclass

import cv2
import numpy as np


def _perspective_maps(H, src_size, warp_size, save_size, post_size):
    S_in = np.array([
        [post_size[0] / src_size[0], 0, 0],
        [0, post_size[1] / src_size[1], 0],
        [0, 0, 1],
    ], dtype=np.float64)
    S_out = np.array([
        [save_size[0] / warp_size[0], 0, 0],
        [0, save_size[1] / warp_size[1], 0],
        [0, 0, 1],
    ], dtype=np.float64)
    Hinv = np.linalg.inv(S_out @ H @ S_in)
    dw, dh = save_size
    xs, ys = np.meshgrid(np.arange(dw, dtype=np.float64), np.arange(dh, dtype=np.float64))
    pts = np.stack([xs.ravel(), ys.ravel(), np.ones(dw * dh)], axis=0)
    src = Hinv @ pts
    src /= src[2]
    return src[0].reshape(dh, dw).astype(np.float32), src[1].reshape(dh, dw).astype(np.float32)


@dataclass
class BirdViewCorrector:
    input_size: tuple
    warp_size: tuple
    save_size: tuple
    homography: np.ndarray
    post_size: tuple
    border_value: tuple = (255, 255, 255)

    def __post_init__(self):
        self.mapx, self.mapy = _perspective_maps(
            self.homography, self.input_size, self.warp_size,
            self.save_size, self.post_size,
        )

    def correct(self, frame: np.ndarray) -> np.ndarray:
        return cv2.remap(
            frame, self.mapx, self.mapy,
            interpolation=cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_CONSTANT,
            borderValue=self.border_value,
        )
