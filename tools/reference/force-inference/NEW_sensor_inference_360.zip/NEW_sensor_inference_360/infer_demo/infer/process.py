"""输入: 1280×720 相机帧，或 640×360（先 resize 到 1280×720 再矫正）。输出: Processed。"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from .batch_post import BirdViewCorrector

cv2.setUseOptimized(True)

INPUT_SIZE = (1280, 720)
POST_SIZE = (2560, 1440)
FLOW_SIZE = (640, 360)
WARP_SIZE = (2154, 1523)
HOMOGRAPHY = np.array([
    [1.9405102947673505, -0.029510258469070856, -689.17422205930859],
    [0.35748905956047777, 1.9090768045081032, -661.8776133515795],
    [0.00035771785981935869, 2.0370458982121464e-05, 1.0],
], dtype=np.float64)


@dataclass
class Processed:
    image: np.ndarray
    flow: np.ndarray


class Processor:
    def __init__(self):
        self.corrector = BirdViewCorrector(
            input_size=INPUT_SIZE,
            warp_size=WARP_SIZE,
            save_size=FLOW_SIZE,
            homography=HOMOGRAPHY,
            post_size=POST_SIZE,
        )
        self.dis = cv2.DISOpticalFlow_create()
        self.bg = None
        self.bg_gray = None

    def __call__(self, frame: np.ndarray, reset=False) -> Processed:
        h, w = frame.shape[:2]
        if (w, h) == FLOW_SIZE:
            frame = cv2.resize(frame, INPUT_SIZE)
        elif (w, h) != INPUT_SIZE:
            raise ValueError(
                f"须 {INPUT_SIZE[0]}x{INPUT_SIZE[1]} 或 {FLOW_SIZE[0]}x{FLOW_SIZE[1]}，"
                f"当前 {w}x{h}。"
            )
        image = self.corrector.correct(frame)
        cur = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        if reset or self.bg is None:
            self.bg = image
            self.bg_gray = cur
            flow = np.zeros((cur.shape[0], cur.shape[1], 2), np.float32)
        else:
            flow = self.dis.calc(self.bg_gray, cur, None)
        return Processed(image=image, flow=flow)


_proc = None
_pending_reset = False


def process(frame, reset=False):
    global _proc, _pending_reset
    if _proc is None:
        _proc = Processor()
    do_reset = reset or _pending_reset
    _pending_reset = False
    return _proc(frame, reset=do_reset)


def request_reset():
    global _pending_reset
    _pending_reset = True
