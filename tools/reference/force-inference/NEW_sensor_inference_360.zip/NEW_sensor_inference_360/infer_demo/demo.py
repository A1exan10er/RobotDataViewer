"""相机须 1280×720。  python demo.py"""
import cv2
from infer import infer, process, show

cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
cap.set(cv2.CAP_PROP_FPS, 60)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

while True:
    cap.grab()
    ok, frame = cap.retrieve()
    if not ok:
        continue




    processed = process(frame, False)   # True: 更换 I0 并清零光流
    force, force_map = infer(processed, cuda=True)
    fx, fy, fz = force              # 合力，单位 N
    fx_map = force_map[:, :, 0]     # 力图 HxW，逐像素 Fx
    fy_map = force_map[:, :, 1]     # 力图 HxW，逐像素 Fy
    fz_map = force_map[:, :, 2]     # 力图 HxW，逐像素 Fz（压力）

  


    show(frame, processed, force, force_map)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
