# -*- coding: utf-8 -*-
"""PSP multitask training: segmentation + fx/fy/fz regression."""
import argparse
import gc
import json
import logging
import random
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
import yaml
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from .data.datasets import MapDataset, filter_valid_pairs, list_pairs
from .models import MultiTaskPSPNet
from .utils.common import ensure_dirs, get_device, read_force_norm_scales, read_shear_max, set_seed
from .utils.metrics import dice_coefficient


def setup_logger(log_dir: str, save_name: str) -> logging.Logger:
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_directory = Path(log_dir)
    log_directory.mkdir(parents=True, exist_ok=True)
    log_path = log_directory / f'{save_name}_{timestamp}.log'

    logger = logging.getLogger('train')
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    formatter = logging.Formatter('[%(asctime)s] %(levelname)s - %(message)s')
    for handler in (logging.FileHandler(log_path, encoding='utf-8'), logging.StreamHandler()):
        handler.setLevel(logging.INFO)
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    logger.info('Log file initialized at %s', log_path)
    return logger


def copy_model_definition(model_key: str, destination_dir: Path) -> None:
    src_models_dir = Path(__file__).parent / 'models'
    mapping = {'psp': 'multitask_pspnet.py'}
    files_to_copy = ['__init__.py']
    if mapping.get(model_key):
        files_to_copy.append(mapping[model_key])

    destination_dir.mkdir(parents=True, exist_ok=True)
    for filename in files_to_copy:
        source_path = src_models_dir / filename
        if source_path.exists():
            shutil.copy2(source_path, destination_dir / filename)


def split_dataset(
    inputs: List[str],
    targets: List[str],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    seed: Optional[int],
    shuffle: bool = True,
    diffs: Optional[List[str]] = None,
) -> Tuple[List[str], List[str], List[str], List[str], List[str], List[str], Optional[List[str]], Optional[List[str]], Optional[List[str]]]:
    assert len(inputs) == len(targets), 'Input/target mismatch'
    if diffs is not None:
        assert len(diffs) == len(inputs), 'Input/diff mismatch'

    if seed is not None and shuffle:
        random.seed(seed)
        indices = list(range(len(inputs)))
        random.shuffle(indices)
        inputs = [inputs[i] for i in indices]
        targets = [targets[i] for i in indices]
        if diffs is not None:
            diffs = [diffs[i] for i in indices]

    n_train = int(len(inputs) * train_ratio)
    n_val = int(len(inputs) * val_ratio)
    n_test = len(inputs) - n_train - n_val

    def take(start: int, count: int) -> Tuple[List[str], List[str], Optional[List[str]]]:
        end = start + max(count, 0)
        slice_diff = diffs[start:end] if diffs is not None else None
        return inputs[start:end], targets[start:end], slice_diff

    train_in, train_lb, train_diff = take(0, n_train)
    val_in, val_lb, val_diff = take(n_train, n_val)
    test_in, test_lb, test_diff = take(n_train + n_val, n_test)
    return train_in, train_lb, val_in, val_lb, test_in, test_lb, train_diff, val_diff, test_diff


def resolve_data_directories(data_cfg: dict) -> Tuple[List[str], List[str], Optional[List[str]]]:
    """Return paired input/label(/diff) directory lists from config."""
    input_dirs = data_cfg.get('input_dirs')
    label_dirs = data_cfg.get('label_dirs')
    diff_dirs = data_cfg.get('diff_dirs')
    if input_dirs is not None or label_dirs is not None:
        if not input_dirs or not label_dirs:
            raise ValueError('data.input_dirs and data.label_dirs must both be provided.')
        if isinstance(input_dirs, str):
            input_dirs = [input_dirs]
        if isinstance(label_dirs, str):
            label_dirs = [label_dirs]
        if len(input_dirs) != len(label_dirs):
            raise ValueError('data.input_dirs and data.label_dirs length mismatch.')
        if diff_dirs is not None:
            if isinstance(diff_dirs, str):
                diff_dirs = [diff_dirs]
            if len(diff_dirs) != len(input_dirs):
                raise ValueError('data.diff_dirs and data.input_dirs length mismatch.')
            return list(input_dirs), list(label_dirs), list(diff_dirs)
        return list(input_dirs), list(label_dirs), None

    primary_input = data_cfg.get('input_dir', '/hy-tmp/original_data/Optical_Flow')
    primary_label = data_cfg.get('label_dir', '/hy-tmp/original_data/Force_Map')
    if not primary_input or not primary_label:
        raise ValueError('data.input_dir and data.label_dir must be provided.')

    pairs = [(str(Path(primary_input)), str(Path(primary_label)))]
    aug_input = data_cfg.get('augmented_input_dir')
    aug_label = data_cfg.get('augmented_label_dir')
    if aug_input and aug_label:
        aug_pair = (str(Path(aug_input)), str(Path(aug_label)))
        if aug_pair not in pairs:
            pairs.append(aug_pair)

    primary_diff = data_cfg.get('diff_dir')
    if primary_diff:
        diff_list = [str(Path(primary_diff))]
        aug_diff = data_cfg.get('augmented_diff_dir')
        if aug_input and aug_label and aug_diff:
            diff_list.append(str(Path(aug_diff)))
        if len(diff_list) != len(pairs):
            raise ValueError('diff_dir/augmented_diff_dir must align with input/label dirs.')
        return [p[0] for p in pairs], [p[1] for p in pairs], diff_list

    return [p[0] for p in pairs], [p[1] for p in pairs], None


def write_split_manifests(
    destination: Path,
    validation_inputs: Sequence[str],
    validation_labels: Sequence[str],
    test_inputs: Sequence[str],
    test_labels: Sequence[str],
    validation_diffs: Optional[Sequence[str]] = None,
    test_diffs: Optional[Sequence[str]] = None,
) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    manifest = {
        'validation_inputs': list(validation_inputs),
        'validation_labels': list(validation_labels),
        'test_inputs': list(test_inputs),
        'test_labels': list(test_labels),
    }
    if validation_diffs is not None:
        manifest['validation_diffs'] = list(validation_diffs)
    if test_diffs is not None:
        manifest['test_diffs'] = list(test_diffs)
    with (destination / 'dataset_splits.json').open('w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)

    file_triplets = (
        ('validation_files.txt', validation_inputs, validation_labels, validation_diffs),
        ('test_files.txt', test_inputs, test_labels, test_diffs),
    )
    for filename, inputs, labels, diffs in file_triplets:
        with (destination / filename).open('w', encoding='utf-8') as f:
            for i, (in_path, lb_path) in enumerate(zip(inputs, labels)):
                if diffs is not None:
                    f.write(f'{in_path} | {diffs[i]} -> {lb_path}\n')
                else:
                    f.write(f'{in_path} -> {lb_path}\n')


def compute_batch_losses(model: nn.Module, batch: Tuple[torch.Tensor, dict], device: torch.device,
                         loss_kwargs: dict) -> Dict[str, torch.Tensor]:
    inputs, targets = batch
    inputs = inputs.to(device)
    segment_bce_weight, segment_dice_weight = loss_kwargs['segment_loss_weight'], loss_kwargs['dice_loss_weight']
    fz_loss_weight = float(loss_kwargs['fz_loss_weight'])
    fz_max = float(loss_kwargs['fz_max'])
    normalize = bool(loss_kwargs.get('normalize', True))
    use_shear_magnitude = bool(loss_kwargs.get('use_shear_magnitude', False))

    true_segmentation = targets['segmentation'].to(device)
    true_force = targets['force'].to(device)

    pred_segmentation, pred_force = model(inputs)
    loss_segment = F.binary_cross_entropy(pred_segmentation, true_segmentation)
    loss_dice = 1.0 - dice_coefficient(true_segmentation, pred_segmentation)

    low_force_max = float(loss_kwargs.get('low_force_max_n', 2.0))
    low_force_mult = float(loss_kwargs.get('low_force_loss_multiplier', 1.0))

    if use_shear_magnitude:
        shear_max = float(loss_kwargs['shear_max'])
        shear_loss_weight = float(loss_kwargs['shear_loss_weight'])
        true_shear = true_force[:, 0]
        true_fz = true_force[:, 1]
        pred_shear = F.relu(pred_force[:, 0])
        pred_fz = pred_force[:, 1]

        true_shear_phys = true_shear * shear_max if normalize else true_shear
        true_fz_phys = true_fz * fz_max if normalize else true_fz
        in_low_force = (
            (true_shear_phys <= low_force_max)
            & (true_fz_phys >= 0.0) & (true_fz_phys <= low_force_max)
        )
        sample_weight = torch.where(
            in_low_force,
            torch.full_like(true_shear, low_force_mult),
            torch.ones_like(true_shear),
        )

        loss_shear = (F.l1_loss(pred_shear, true_shear, reduction='none') * sample_weight).mean()
        loss_fz = (F.l1_loss(pred_fz, true_fz, reduction='none') * sample_weight).mean()

        pred_shear_phys = pred_shear * shear_max if normalize else pred_shear
        pred_fz_phys = pred_fz * fz_max if normalize else pred_fz
        disp_sum_mae_shear = F.l1_loss(pred_shear_phys, true_shear_phys)
        disp_sum_mae_fz = F.l1_loss(pred_fz_phys, true_fz_phys)

        weighted_loss_segment = segment_bce_weight * loss_segment
        weighted_loss_dice = segment_dice_weight * loss_dice
        weighted_loss_shear = shear_loss_weight * loss_shear
        weighted_loss_fz = fz_loss_weight * loss_fz
        total_loss = weighted_loss_segment + weighted_loss_dice + weighted_loss_shear + weighted_loss_fz

        zero = torch.zeros((), device=device)
        return {
            'loss': total_loss, 'loss_segment': weighted_loss_segment, 'loss_dice': weighted_loss_dice,
            'loss_shear': weighted_loss_shear, 'loss_fz': weighted_loss_fz,
            'loss_fx': zero, 'loss_fy': zero,
            'disp_sum_mae_shear': disp_sum_mae_shear, 'disp_sum_mae_fz': disp_sum_mae_fz,
            'disp_sum_mae_fx': zero, 'disp_sum_mae_fy': zero,
            'dice': dice_coefficient(true_segmentation, pred_segmentation),
        }

    fx_loss_weight = float(loss_kwargs['fx_loss_weight'])
    fy_loss_weight = float(loss_kwargs['fy_loss_weight'])
    fx_max = float(loss_kwargs['fx_max'])
    fy_max = float(loss_kwargs['fy_max'])

    true_fx = true_force[:, 0]
    true_fy = true_force[:, 1]
    true_fz = true_force[:, 2]
    pred_fx = pred_force[:, 0]
    pred_fy = pred_force[:, 1]
    pred_fz = pred_force[:, 2]

    if normalize:
        true_fx_phys = true_fx * fx_max
        true_fy_phys = true_fy * fy_max
        true_fz_phys = true_fz * fz_max
    else:
        true_fx_phys, true_fy_phys, true_fz_phys = true_fx, true_fy, true_fz

    in_low_force = (
        (true_fx_phys.abs() <= low_force_max)
        & (true_fy_phys.abs() <= low_force_max)
        & (true_fz_phys >= 0.0) & (true_fz_phys <= low_force_max)
    )
    sample_weight = torch.where(
        in_low_force,
        torch.full_like(true_fx, low_force_mult),
        torch.ones_like(true_fx),
    )

    loss_fx = (F.l1_loss(pred_fx, true_fx, reduction='none') * sample_weight).mean()
    loss_fy = (F.l1_loss(pred_fy, true_fy, reduction='none') * sample_weight).mean()
    loss_fz = (F.l1_loss(pred_fz, true_fz, reduction='none') * sample_weight).mean()

    pred_fx_phys = pred_fx * fx_max if normalize else pred_fx
    pred_fy_phys = pred_fy * fy_max if normalize else pred_fy
    pred_fz_phys = pred_fz * fz_max if normalize else pred_fz
    disp_sum_mae_fx = F.l1_loss(pred_fx_phys, true_fx_phys)
    disp_sum_mae_fy = F.l1_loss(pred_fy_phys, true_fy_phys)
    disp_sum_mae_fz = F.l1_loss(pred_fz_phys, true_fz_phys)

    weighted_loss_segment = segment_bce_weight * loss_segment
    weighted_loss_dice = segment_dice_weight * loss_dice
    weighted_loss_fx = fx_loss_weight * loss_fx
    weighted_loss_fy = fy_loss_weight * loss_fy
    weighted_loss_fz = fz_loss_weight * loss_fz
    total_loss = (weighted_loss_segment + weighted_loss_dice + weighted_loss_fx
                  + weighted_loss_fy + weighted_loss_fz)

    zero = torch.zeros((), device=device)
    return {
        'loss': total_loss, 'loss_segment': weighted_loss_segment, 'loss_dice': weighted_loss_dice,
        'loss_fx': weighted_loss_fx, 'loss_fy': weighted_loss_fy, 'loss_fz': weighted_loss_fz,
        'loss_shear': zero,
        'disp_sum_mae_fx': disp_sum_mae_fx, 'disp_sum_mae_fy': disp_sum_mae_fy,
        'disp_sum_mae_fz': disp_sum_mae_fz, 'disp_sum_mae_shear': zero,
        'dice': dice_coefficient(true_segmentation, pred_segmentation),
    }


_PAIR_CACHE_VERSION = 2


_PAIR_LOG_SAMPLE_LIMIT = 5


def _log_unmatched_pair_files(
    logger: logging.Logger,
    idx: int,
    pair_stats: dict,
    in_dir: str,
    lb_dir: str,
    diff_dir: Optional[str] = None,
) -> None:
    unmatched_in = pair_stats.get('unmatched_inputs', [])
    unmatched_lb = pair_stats.get('unmatched_labels', [])
    unmatched_diffs = pair_stats.get('unmatched_diffs', [])
    if unmatched_in:
        logger.warning('[Pair %d] %d input(s) without matching label under %s',
                       idx, len(unmatched_in), in_dir)
        for path in unmatched_in[:_PAIR_LOG_SAMPLE_LIMIT]:
            logger.warning('  unmatched input: %s', path)
        remaining = len(unmatched_in) - _PAIR_LOG_SAMPLE_LIMIT
        if remaining > 0:
            logger.warning('  ... and %d more unmatched input(s)', remaining)
    if unmatched_lb:
        logger.warning('[Pair %d] %d label(s) without matching input under %s',
                       idx, len(unmatched_lb), lb_dir)
        for path in unmatched_lb[:_PAIR_LOG_SAMPLE_LIMIT]:
            logger.warning('  unmatched label: %s', path)
        remaining = len(unmatched_lb) - _PAIR_LOG_SAMPLE_LIMIT
        if remaining > 0:
            logger.warning('  ... and %d more unmatched label(s)', remaining)
    if unmatched_diffs:
        logger.warning(
            '[Pair %d] %d input(s) without matching Image_Diff under %s',
            idx, len(unmatched_diffs), diff_dir or '(diff_dir)',
        )
        for path in unmatched_diffs[:_PAIR_LOG_SAMPLE_LIMIT]:
            logger.warning('  unmatched diff for input: %s', path)
        remaining = len(unmatched_diffs) - _PAIR_LOG_SAMPLE_LIMIT
        if remaining > 0:
            logger.warning('  ... and %d more unmatched diff(s)', remaining)


def _discover_pair_groups(
    input_dirs: List[str],
    label_dirs: List[str],
    logger: logging.Logger,
    verify_finite: bool = False,
    diff_dirs: Optional[List[str]] = None,
) -> Tuple[List[dict], List[str], List[str], Optional[List[str]]]:
    """Scan disk for input/label(/diff) pairs grouped by source directory."""
    groups: List[dict] = []
    all_inputs: List[str] = []
    all_labels: List[str] = []
    all_diffs: Optional[List[str]] = [] if diff_dirs is not None else None
    dir_triples = zip(
        input_dirs,
        label_dirs,
        diff_dirs if diff_dirs is not None else [None] * len(input_dirs),
    )
    for idx, (in_dir, lb_dir, diff_dir) in enumerate(dir_triples, start=1):
        in_files, lb_files, pair_stats, diff_files = list_pairs(in_dir, lb_dir, diff_dir=diff_dir)
        _log_unmatched_pair_files(logger, idx, pair_stats, in_dir, lb_dir, diff_dir=diff_dir)
        in_files, lb_files, skipped, diff_files = filter_valid_pairs(
            in_files, lb_files, verify=verify_finite, diff_files=diff_files)
        if skipped:
            logger.warning('[Pair %d] Skipped %d unreadable files under %s', idx, len(skipped), in_dir)
        if not in_files or not lb_files:
            raise ValueError(f'No data found under input_dir={in_dir} or label_dir={lb_dir}')
        if len(in_files) != len(lb_files):
            raise ValueError(f'Unmatched counts for input_dir={in_dir} ({len(in_files)}) '
                             f'and label_dir={lb_dir} ({len(lb_files)})')
        if diff_dir is not None:
            if not diff_files:
                raise ValueError(f'No Image_Diff matched under diff_dir={diff_dir}')
            if len(diff_files) != len(in_files):
                raise ValueError(
                    f'Unmatched counts for input_dir={in_dir} ({len(in_files)}) '
                    f'and diff_dir={diff_dir} ({len(diff_files)})'
                )
        if diff_dir is not None:
            logger.info(
                '[Pair %d] Discovered %d files: %s | %s | %s',
                idx, len(in_files), in_dir, diff_dir, lb_dir,
            )
        else:
            logger.info('[Pair %d] Discovered %d files: %s | %s', idx, len(in_files), in_dir, lb_dir)
        group = {
            'input_dir': str(in_dir),
            'label_dir': str(lb_dir),
            'inputs': in_files,
            'labels': lb_files,
        }
        if diff_dir is not None:
            group['diff_dir'] = str(diff_dir)
            group['diffs'] = list(diff_files or [])
        groups.append(group)
        all_inputs.extend(in_files)
        all_labels.extend(lb_files)
        if all_diffs is not None:
            all_diffs.extend(diff_files or [])
    return groups, all_inputs, all_labels, all_diffs


def _pair_cache_payload(
    input_dirs: List[str],
    label_dirs: List[str],
    groups: List[dict],
    all_inputs: List[str],
    all_labels: List[str],
    diff_dirs: Optional[List[str]] = None,
    all_diffs: Optional[List[str]] = None,
) -> dict:
    payload = {
        'version': _PAIR_CACHE_VERSION,
        'input_dirs': list(input_dirs),
        'label_dirs': list(label_dirs),
        'inputs': all_inputs,
        'labels': all_labels,
        'groups': groups,
    }
    if diff_dirs is not None:
        payload['diff_dirs'] = list(diff_dirs)
    if all_diffs is not None:
        payload['diffs'] = all_diffs
    return payload


def _pair_cache_matches(cache_data: dict, payload: dict) -> bool:
    if cache_data.get('version') != _PAIR_CACHE_VERSION:
        return False
    if cache_data.get('input_dirs') != payload['input_dirs']:
        return False
    if cache_data.get('label_dirs') != payload['label_dirs']:
        return False
    if cache_data.get('diff_dirs') != payload.get('diff_dirs'):
        return False
    cached_groups = cache_data.get('groups') or []
    fresh_groups = payload['groups']
    if len(cached_groups) != len(fresh_groups):
        return False
    for cached_group, fresh_group in zip(cached_groups, fresh_groups):
        if sorted(cached_group.get('inputs', [])) != sorted(fresh_group['inputs']):
            return False
        if sorted(cached_group.get('labels', [])) != sorted(fresh_group['labels']):
            return False
        if sorted(cached_group.get('diffs', [])) != sorted(fresh_group.get('diffs', [])):
            return False
    return True


def _folder_tag(input_dir: str) -> str:
    """Return a short folder label such as N6 from .../N6/Optical_Flow."""
    parent = Path(input_dir).parent.name
    return parent if parent else Path(input_dir).name


def _split_from_groups(
    groups: List[dict],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    seed: Optional[int],
    logger: Optional[logging.Logger] = None,
) -> Tuple[List[str], List[str], List[str], List[str], List[str], List[str], Optional[List[str]], Optional[List[str]], Optional[List[str]]]:
    """Split each source folder independently, then merge (same ratio per folder)."""
    train_in, train_lb, val_in, val_lb, test_in, test_lb = [], [], [], [], [], []
    train_diff, val_diff, test_diff = [], [], []
    use_diff = any('diffs' in group for group in groups)
    for idx, group in enumerate(groups, start=1):
        in_files = list(group['inputs'])
        lb_files = list(group['labels'])
        diff_files = list(group['diffs']) if use_diff else None
        src_seed = (seed + idx) if seed is not None else None
        ti, tl, vi, vl, te, tel, td, vd, ted = split_dataset(
            in_files, lb_files, train_ratio, val_ratio, test_ratio, src_seed, diffs=diff_files)
        train_in.extend(ti)
        train_lb.extend(tl)
        val_in.extend(vi)
        val_lb.extend(vl)
        test_in.extend(te)
        test_lb.extend(tel)
        if use_diff:
            train_diff.extend(td or [])
            val_diff.extend(vd or [])
            test_diff.extend(ted or [])
        if logger is not None:
            total = len(in_files)
            if total == 0:
                continue
            folder = _folder_tag(group['input_dir'])
            logger.info(
                '[Pair %d] %s split | total=%d train=%d (%.1f%%) val=%d (%.1f%%) test=%d (%.1f%%)',
                idx, folder, total,
                len(ti), 100.0 * len(ti) / total,
                len(vi), 100.0 * len(vi) / total,
                len(te), 100.0 * len(te) / total,
            )
    if use_diff:
        return train_in, train_lb, val_in, val_lb, test_in, test_lb, train_diff, val_diff, test_diff
    return train_in, train_lb, val_in, val_lb, test_in, test_lb, None, None, None


def prepare_data_splits(
    input_dirs: List[str],
    label_dirs: List[str],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    seed: Optional[int],
    cache_path: Optional[Path],
    logger: logging.Logger,
    split_per_folder: bool = True,
    verify_finite: bool = False,
    diff_dirs: Optional[List[str]] = None,
) -> Tuple[List[str], List[str], List[str], List[str], List[str], List[str], Optional[List[str]], Optional[List[str]], Optional[List[str]]]:
    """Split train/val/test; by default each input_dirs/label_dirs pair is split independently."""
    groups, all_inputs, all_labels, all_diffs = _discover_pair_groups(
        input_dirs, label_dirs, logger, verify_finite=verify_finite, diff_dirs=diff_dirs)
    payload = _pair_cache_payload(
        input_dirs, label_dirs, groups, all_inputs, all_labels,
        diff_dirs=diff_dirs, all_diffs=all_diffs,
    )

    if cache_path and cache_path.exists():
        with cache_path.open('r', encoding='utf-8') as f:
            cache_data = json.load(f)
        if _pair_cache_matches(cache_data, payload):
            logger.info('Pair cache is up to date: %s | groups=%d inputs=%d',
                        cache_path, len(groups), len(all_inputs))
        else:
            logger.warning('Pair cache stale or mismatched; refreshing %s', cache_path)

    if split_per_folder:
        logger.info(
            'Splitting per folder with ratios train=%.2f val=%.2f test=%.2f',
            train_ratio, val_ratio, test_ratio,
        )
        splits = _split_from_groups(
            groups, train_ratio, val_ratio, test_ratio, seed, logger=logger)
    else:
        logger.warning(
            'split_per_folder=false: pooling all folders then splitting once '
            '(large folders dominate train/val/test sizes).'
        )
        splits = split_dataset(
            all_inputs, all_labels, train_ratio, val_ratio, test_ratio, seed, diffs=all_diffs)

    if cache_path:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        with cache_path.open('w', encoding='utf-8') as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        logger.info('Saved pair cache to %s', cache_path)

    return splits


def load_pretrained_weights(model: nn.Module, pretrained_model_dir: Optional[str], device: torch.device,
                            logger: logging.Logger) -> None:
    if pretrained_model_dir is None:
        return

    pretrained_path = Path(pretrained_model_dir).expanduser().resolve()
    if not pretrained_path.exists():
        logger.warning('Pretrained path %s not found; skipping', pretrained_path)
        return

    if pretrained_path.is_file():
        weights_path = pretrained_path
    elif pretrained_path.is_dir():
        pt_files = list(pretrained_path.glob('*.pt'))
        if not pt_files:
            raise FileNotFoundError(f'No .pt weights found in {pretrained_path}')
        weights_path = sorted(pt_files, key=lambda p: p.name)[0]
    else:
        logger.warning('Pretrained path %s is invalid; skipping', pretrained_path)
        return

    state_dict = torch.load(weights_path, map_location=device)
    model.load_state_dict(state_dict)
    logger.info('Loaded pretrained weights from %s', weights_path)


def run_epoch(model: nn.Module, loader: DataLoader, device: torch.device, *, train: bool, epoch: int, epochs: int,
              loss_kwargs: dict, optimizer: Optional[torch.optim.Optimizer] = None) -> Dict[str, float]:
    metric_keys = ('loss', 'loss_segment', 'loss_dice', 'loss_shear', 'loss_fx', 'loss_fy', 'loss_fz',
                   'disp_sum_mae_shear', 'disp_sum_mae_fx', 'disp_sum_mae_fy', 'disp_sum_mae_fz', 'dice')
    running = {key: 0.0 for key in metric_keys}
    running['n'] = 0
    phase = 'train' if train else 'val'
    progress = tqdm(loader, desc=f'Epoch {epoch}/{epochs} [{phase}]', leave=False, ncols=100)

    context = torch.enable_grad() if train else torch.no_grad()
    with context:
        model.train() if train else model.eval()
        for batch in progress:
            batch_losses = compute_batch_losses(model, batch, device, loss_kwargs)
            if train:
                optimizer.zero_grad(set_to_none=True)
                batch_losses['loss'].backward()
                optimizer.step()

            batch_size = batch[0].size(0)
            for key in metric_keys:
                running[key] += float(batch_losses[key].item()) * batch_size
            running['n'] += batch_size
            n = max(running['n'], 1)
            if train:
                progress.set_postfix({'loss': f'{running["loss"] / n:.4f}'})
            else:
                if loss_kwargs.get('use_shear_magnitude'):
                    progress.set_postfix({
                        'loss': f'{running["loss"] / n:.4f}',
                        'shear': f'{running["disp_sum_mae_shear"] / n:.4e}',
                        'fz': f'{running["disp_sum_mae_fz"] / n:.4e}',
                    })
                else:
                    progress.set_postfix({
                        'loss': f'{running["loss"] / n:.4f}',
                        'fx': f'{running["disp_sum_mae_fx"] / n:.4e}',
                        'fy': f'{running["disp_sum_mae_fy"] / n:.4e}',
                        'fz': f'{running["disp_sum_mae_fz"] / n:.4e}',
                    })

    n = max(running['n'], 1)
    return {key: running[key] / n for key in metric_keys}


def save_best_checkpoint(model: nn.Module, val_loss: float, save_name: str, out_models: str, out_results: str, config_path: Path, model_name: str,
                         val_in: List[str], val_lb: List[str], test_in: List[str], test_lb: List[str], best_model_dir: Optional[Path], best_results_dir: Optional[Path], logger: logging.Logger,
                         val_diff: Optional[List[str]] = None, test_diff: Optional[List[str]] = None) -> Tuple[Path, Path]:
    base_name = f'{save_name}_valloss_{val_loss:.4f}'
    models_base = Path(out_models)
    results_base = Path(out_results)
    run_dir = models_base / base_name

    suffix = 1
    while run_dir.exists() or (results_base / run_dir.name).exists():
        run_dir = models_base / f'{base_name}_{suffix:02d}'
        suffix += 1

    if best_model_dir and best_model_dir.exists():
        shutil.rmtree(best_model_dir)
    if best_results_dir and best_results_dir.exists():
        shutil.rmtree(best_results_dir)

    run_dir.mkdir(parents=True, exist_ok=False)
    results_dir = results_base / run_dir.name
    results_dir.mkdir(parents=True, exist_ok=False)

    write_split_manifests(
        run_dir, val_in, val_lb, test_in, test_lb,
        validation_diffs=val_diff, test_diffs=test_diff,
    )
    save_path = run_dir / f'{save_name}.pt'
    torch.save(model.state_dict(), str(save_path))
    copy_model_definition(model_name, run_dir)
    shutil.copy2(config_path, run_dir / config_path.name)
    shutil.copy2(Path(__file__), run_dir / 'train.py')
    logger.info('New best model (val_loss=%.4f) saved to %s', val_loss, save_path)
    return run_dir, results_dir


def main(cfg_path: str) -> None:
    config_path = Path(cfg_path).expanduser().resolve()
    with config_path.open('r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    data_cfg = cfg['data']
    train_cfg = cfg['train']
    loss_cfg = cfg['Loss']
    output_cfg = cfg['output']

    input_dirs, label_dirs, diff_dirs = resolve_data_directories(data_cfg)
    mask_threshold = float(data_cfg.get('mask_threshold', 0.01))
    fx_max, fy_max, fz_max = read_force_norm_scales(data_cfg)
    shear_max = read_shear_max(data_cfg, fx_max, fy_max)
    normalize = bool(data_cfg.get('normalize', True))
    use_shear_magnitude = bool(loss_cfg.get('use_shear_magnitude', False))
    num_force_outputs = 2 if use_shear_magnitude else 3
    num_workers = int(data_cfg.get('num_workers', 0))
    verify_finite = bool(data_cfg.get('verify_finite', True))
    pair_cache_file = data_cfg.get('pair_cache_file')
    cache_path = Path(pair_cache_file).expanduser() if pair_cache_file else None

    mask_sum_regression = bool(loss_cfg.get('mask_sum_regression', True))
    loss_kwargs = {
        'segment_loss_weight': float(loss_cfg['segment_loss_weight']),
        'dice_loss_weight': float(loss_cfg['dice_loss_weight']),
        'fx_loss_weight': float(loss_cfg.get('fx_loss_weight', loss_cfg.get('sum_fx_loss_weight', 1.0))),
        'fy_loss_weight': float(loss_cfg.get('fy_loss_weight', loss_cfg.get('sum_fy_loss_weight', 1.0))),
        'fz_loss_weight': float(loss_cfg.get('fz_loss_weight', loss_cfg.get('sum_fz_loss_weight', 1.0))),
        'shear_loss_weight': float(loss_cfg.get('shear_loss_weight', 2.0)),
        'fx_max': fx_max,
        'fy_max': fy_max,
        'fz_max': fz_max,
        'shear_max': shear_max,
        'normalize': normalize,
        'use_shear_magnitude': use_shear_magnitude,
        'low_force_max_n': float(loss_cfg.get('low_force_max_n', 2.0)),
        'low_force_loss_multiplier': float(loss_cfg.get('low_force_loss_multiplier', 1.0)),
    }

    ensure_dirs(output_cfg['models_dir'], output_cfg['logs_dir'], output_cfg['results_dir'])
    save_name = output_cfg.get('save_name', 'FCN')
    logger = setup_logger(output_cfg['logs_dir'], save_name)
    logger.info('Loaded configuration from %s', config_path)
    if diff_dirs is not None:
        logger.info('Using optical flow + Image_Diff concat input (%d channel folders)', len(diff_dirs))

    seed = train_cfg.get('seed')
    if seed is not None:
        set_seed(seed)
        logger.info('Random seed set to %d', seed)

    logger.info('Preparing datasets from %d source pairs', len(input_dirs))
    train_ratio = float(train_cfg['train_ratio'])
    val_ratio = float(train_cfg['val_ratio'])
    test_ratio = float(train_cfg['test_ratio'])
    if abs(train_ratio + val_ratio + test_ratio - 1.0) > 1e-6:
        raise ValueError('train/val/test ratios must sum to 1')

    split_per_folder = bool(data_cfg.get('split_per_folder', True))
    train_in, train_lb, val_in, val_lb, test_in, test_lb, train_diff, val_diff, test_diff = prepare_data_splits(
        input_dirs, label_dirs, train_ratio, val_ratio, test_ratio, seed, cache_path, logger,
        split_per_folder=split_per_folder, verify_finite=verify_finite, diff_dirs=diff_dirs)
    if not train_in and not val_in and not test_in:
        raise ValueError('No data collected from specified directories.')
    logger.info('Split sizes | train=%d val=%d test=%d', len(train_in), len(val_in), len(test_in))

    ds_kwargs = dict(mask_threshold=mask_threshold, mask_sum_regression=mask_sum_regression,
                     normalize=normalize, verify_finite=verify_finite,
                     use_shear_magnitude=use_shear_magnitude,
                     fx_max=fx_max, fy_max=fy_max, fz_max=fz_max, shear_max=shear_max)
    train_ds = MapDataset(train_in, train_lb, diff_img_paths=train_diff, **ds_kwargs)
    val_ds = MapDataset(val_in, val_lb, diff_img_paths=val_diff, **ds_kwargs)

    batch_size = int(train_cfg['batch_size'])
    pin_memory = bool(data_cfg.get('pin_memory', torch.cuda.is_available()))
    loader_kwargs = {'batch_size': batch_size, 'num_workers': num_workers, 'pin_memory': pin_memory}
    if num_workers > 0:
        loader_kwargs['persistent_workers'] = True
        loader_kwargs['prefetch_factor'] = int(data_cfg.get('prefetch_factor', 2))
    train_loader = DataLoader(train_ds, shuffle=True, drop_last=True, **loader_kwargs)
    val_loader = DataLoader(val_ds, shuffle=False, drop_last=False, **loader_kwargs)
    logger.info('Data loaders ready | batch_size=%d num_workers=%d', batch_size, num_workers)
    if use_shear_magnitude:
        logger.info('Force targets: shear_magnitude + fz | shear_max=%.4f num_force_outputs=%d',
                    shear_max, num_force_outputs)

    device = get_device()
    logger.info('Using device: %s', device)

    model_name = cfg['model']['name'].lower()
    if model_name != 'psp':
        raise ValueError(f"Unsupported model name: {cfg['model']['name']}")

    in_channels = int(cfg['model'].get('in_channels', 2 if diff_dirs is None else 3))
    if diff_dirs is not None and in_channels < 3:
        raise ValueError(f'model.in_channels must be >= 3 when using diff_dirs (got {in_channels})')
    model = MultiTaskPSPNet(in_channels=in_channels,
                            num_classes=int(cfg['model'].get('num_classes', 2)),
                            pretrained_backbone=bool(cfg['model'].get('pretrained_backbone', False)),
                            num_force_outputs=num_force_outputs)
    load_pretrained_weights(model, cfg['model'].get('pretrained_model'), device, logger)
    model.to(device)
    logger.info('Model initialized: %s | in_channels=%d', model.__class__.__name__, in_channels)

    lr = float(train_cfg['learning_rate'])
    wd = float(train_cfg.get('weight_decay', 1e-4))
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=wd)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5, min_lr=1e-6)
    logger.info('Optimizer configured: AdamW lr=%.3e weight_decay=%.3e', lr, wd)

    epochs = int(train_cfg['epochs'])
    best_val = float('inf')
    best_model_dir: Optional[Path] = None
    best_results_dir: Optional[Path] = None
    logger.info('Starting training for %d epochs', epochs)

    for epoch in range(1, epochs + 1):
        train_metrics = run_epoch(model, train_loader, device, train=True, epoch=epoch, epochs=epochs,
                                  loss_kwargs=loss_kwargs, optimizer=optimizer)
        if use_shear_magnitude:
            logger.info(
                'Epoch %d/%d - train: loss=%.4f dice=%.4f | 物理MAE shear=%.6e fz=%.6e',
                epoch, epochs, train_metrics['loss'], train_metrics['dice'],
                train_metrics['disp_sum_mae_shear'], train_metrics['disp_sum_mae_fz'],
            )
        else:
            logger.info(
                'Epoch %d/%d - train: loss=%.4f dice=%.4f | 物理MAE fx=%.6e fy=%.6e fz=%.6e',
                epoch, epochs, train_metrics['loss'], train_metrics['dice'],
                train_metrics['disp_sum_mae_fx'], train_metrics['disp_sum_mae_fy'], train_metrics['disp_sum_mae_fz'],
            )

        val_metrics = run_epoch(model, val_loader, device, train=False, epoch=epoch, epochs=epochs, loss_kwargs=loss_kwargs)
        scheduler.step(val_metrics['loss'])
        if use_shear_magnitude:
            logger.info(
                'Epoch %d/%d - val: loss=%.4f dice=%.4f | 物理MAE shear=%.6e fz=%.6e',
                epoch, epochs, val_metrics['loss'], val_metrics['dice'],
                val_metrics['disp_sum_mae_shear'], val_metrics['disp_sum_mae_fz'],
            )
        else:
            logger.info(
                'Epoch %d/%d - val: loss=%.4f dice=%.4f | 物理MAE fx=%.6e fy=%.6e fz=%.6e',
                epoch, epochs, val_metrics['loss'], val_metrics['dice'],
                val_metrics['disp_sum_mae_fx'], val_metrics['disp_sum_mae_fy'], val_metrics['disp_sum_mae_fz'],
            )

        if val_metrics['loss'] < best_val:
            best_val = val_metrics['loss']
            best_model_dir, best_results_dir = save_best_checkpoint(
                model, val_metrics['loss'], save_name, output_cfg['models_dir'],
                output_cfg['results_dir'], config_path, model_name, val_in, val_lb,
                test_in, test_lb, best_model_dir, best_results_dir, logger,
                val_diff=val_diff, test_diff=test_diff,
            )

    last_ckpt_path = Path(output_cfg['models_dir']) / f'{save_name}_last.pt'
    last_ckpt_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), str(last_ckpt_path))
    logger.info('Saved last epoch weights to %s', last_ckpt_path)

    del optimizer, scheduler, train_loader, val_loader, model
    del train_ds, val_ds
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    if best_model_dir:
        cmd = [sys.executable, '-m', 'src.eval_test', '--model-dir', str(best_model_dir), '--device', str(device)]
        if best_results_dir:
            cmd.extend(['--results-dir', str(best_results_dir)])
        logger.info('Evaluating on test dataset (subprocess)')
        proc = subprocess.run(cmd, check=False)
        if proc.returncode != 0:
            logger.error('Test evaluation failed (exit %d): %s', proc.returncode, ' '.join(cmd))
    else:
        logger.warning('No best model saved; skipping test evaluation')

    if best_model_dir:
        logger.info('Best model directory: %s', best_model_dir)
    if best_results_dir:
        logger.info('Best results directory: %s', best_results_dir)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--config', default='config/psp_all.yaml')
    args = parser.parse_args()
    main(args.config)
