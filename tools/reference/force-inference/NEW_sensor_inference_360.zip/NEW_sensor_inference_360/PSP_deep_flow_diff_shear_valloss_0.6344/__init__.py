from .multitask_pspnet import MultiTaskPSPNet

__all__ = [
    'MultiTaskPSPNet',
]
