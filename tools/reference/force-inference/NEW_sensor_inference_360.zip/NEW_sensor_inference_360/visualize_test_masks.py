"""对 test_files.txt 中的样本做模型推理，将分割掩模叠加到 640×360 原图并保存。"""
import argparse
import os
from pathlib import Path

import cv2
import numpy as np
import torch
from tqdm import tqdm

from main import ForceNet

SEG_THRESHOLD = 0.01
DEFAULT_TEST_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "PSP_simulation_stage1_valrmse_0.0000_04",
    "test_files.txt",
)
DEFAULT_OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "PSP_simulation_stage1_valrmse_0.0000_04",
    "test_mask_overlay",
)


def parse_test_files(path):
    pairs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or "->" not in line:
                continue
            flow_path, _ = [part.strip() for part in line.split("->", 1)]
            pairs.append(flow_path)
    return pairs


def flow_path_to_image_path(flow_path):
    """OpticalFlow3-0-5-0.1-2.0-x.npz -> Original_Images_640x360/O_Image3-0-5-0.1-2.0-x.jpg"""
    flow_path = Path(flow_path)
    stem = flow_path.stem
    if stem.startswith("OpticalFlow"):
        image_stem = "O_Image" + stem[len("OpticalFlow"):]
    else:
        image_stem = stem
    return flow_path.parent.parent / "Original_Images_640x360" / f"{image_stem}.jpg"


def load_flow(flow_path):
    data = np.load(flow_path)
    flow = data["flow"].astype(np.float32)
    if flow.ndim != 3 or flow.shape[2] != 2:
        raise ValueError(f"光流形状异常: {flow_path} -> {flow.shape}")
    return flow


def overlay_masks(image, pre_mask, she_mask, alpha=0.45):
    color = np.zeros_like(image)
    color[pre_mask] = (0, 0, 255)      # 压力: 红
    color[she_mask] = (0, 255, 0)       # 剪切: 绿
    color[pre_mask & she_mask] = (0, 255, 255)  # 重叠: 黄
    return cv2.addWeighted(image, 1.0 - alpha, color, alpha, 0)


def save_result(image, pre_prob, she_prob, out_path, seg_threshold):
    pre_mask = pre_prob >= seg_threshold
    she_mask = she_prob >= seg_threshold
    overlay = overlay_masks(image, pre_mask, she_mask)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out_path), overlay)


def main():
    parser = argparse.ArgumentParser(description="测试集掩模可视化")
    parser.add_argument("--test-file", default=DEFAULT_TEST_FILE)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--seg-threshold", type=float, default=SEG_THRESHOLD)
    parser.add_argument("--limit", type=int, default=0, help="仅处理前 N 条，0 表示全部")
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()

    flow_paths = parse_test_files(args.test_file)
    if args.limit > 0:
        flow_paths = flow_paths[:args.limit]

    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    net = ForceNet(device)
    output_dir = Path(args.output_dir)

    missing_images = 0
    failed = 0

    for flow_path in tqdm(flow_paths, desc="推理并保存"):
        image_path = flow_path_to_image_path(flow_path)
        if not image_path.is_file():
            missing_images += 1
            continue

        image = cv2.imread(str(image_path))
        if image is None:
            failed += 1
            continue

        try:
            flow = load_flow(flow_path)
            flow_tensor = torch.from_numpy(flow).permute(2, 0, 1).unsqueeze(0).float().to(device)
            with torch.inference_mode():
                seg_probs, _, _ = net(flow_tensor)
            pre_prob = seg_probs[0, 0].float().cpu().numpy()
            she_prob = seg_probs[0, 1].float().cpu().numpy()

            rel = image_path.relative_to(image_path.parents[2])  # N23/Original_Images_640x360/xxx.jpg
            out_path = output_dir / rel.parent.parent / f"{image_path.stem}_overlay.jpg"
            save_result(image, pre_prob, she_prob, out_path, args.seg_threshold)
        except Exception:
            failed += 1

    print(f"完成: 共 {len(flow_paths)} 条")
    print(f"输出目录: {output_dir}")
    if missing_images:
        print(f"缺少原图: {missing_images}")
    if failed:
        print(f"处理失败: {failed}")


if __name__ == "__main__":
    main()
