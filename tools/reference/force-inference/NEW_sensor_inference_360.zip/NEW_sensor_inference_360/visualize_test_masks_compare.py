"""GT + 预测掩模叠在原图上。压力、剪切分开保存，不混在一张图里。"""
import argparse
import os
from pathlib import Path

import cv2
import numpy as np
import torch
from tqdm import tqdm

from main import ForceNet

GT_MASK_THRESHOLD = 5e-5
PRED_SEG_THRESHOLD = 0.01
DEFAULT_TEST_FILE = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "PSP_simulation_stage1_valrmse_0.0000_04",
    "test_files.txt",
)
DEFAULT_OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "PSP_simulation_stage1_valrmse_0.0000_04",
    "test_mask_compare",
)

MASK_TYPES = {
    "pressure": {"color": (0, 0, 255), "title": "Pressure"},
    "shear": {"color": (0, 255, 0), "title": "Shear"},
}


def parse_test_pairs(path):
    pairs = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or "->" not in line:
                continue
            flow_path, label_path = [part.strip() for part in line.split("->", 1)]
            pairs.append((flow_path, label_path))
    return pairs


def flow_path_to_image_path(flow_path):
    flow_path = Path(flow_path)
    stem = flow_path.stem
    if stem.startswith("OpticalFlow"):
        image_stem = "O_Image" + stem[len("OpticalFlow"):]
    else:
        image_stem = stem
    return flow_path.parent.parent / "Original_Images_640x360" / f"{image_stem}.jpg"


def load_flow(flow_path):
    flow = np.load(flow_path)["flow"].astype(np.float32)
    if flow.ndim != 3 or flow.shape[2] != 2:
        raise ValueError(f"光流形状异常: {flow_path} -> {flow.shape}")
    return flow


def load_gt_masks(label_path, mask_threshold):
    force_map = np.load(label_path)["data"].astype(np.float32)
    pressure = force_map[:, :, 2]
    shear = np.sqrt(force_map[:, :, 0] ** 2 + force_map[:, :, 1] ** 2)
    return pressure > mask_threshold, shear > mask_threshold


def draw_contour(img, mask, color, thickness=2):
    mask_u8 = (mask.astype(np.uint8) * 255)
    contours, _ = cv2.findContours(mask_u8, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(img, contours, -1, color, thickness, lineType=cv2.LINE_AA)


def blend_fill(img, mask, color, alpha=0.4):
    if not mask.any():
        return img
    out = img.astype(np.float32)
    color_arr = np.array(color, dtype=np.float32)
    out[mask] = out[mask] * (1.0 - alpha) + color_arr * alpha
    return out.astype(np.uint8)


def draw_legend(img, title):
    lines = (title, "Pred: fill", "GT: contour")
    x, y0, line_h = 10, 22, 20
    box_w, box_h = 160, 8 + line_h * len(lines)
    overlay = img.copy()
    cv2.rectangle(overlay, (4, 4), (4 + box_w, 4 + box_h), (0, 0, 0), -1)
    img[:] = cv2.addWeighted(overlay, 0.5, img, 0.5, 0)
    for i, text in enumerate(lines):
        cv2.putText(
            img, text, (x, y0 + i * line_h),
            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1, cv2.LINE_AA,
        )


def make_overlay(image, gt_mask, pred_mask, color, title):
    out = image.copy()
    out = blend_fill(out, pred_mask, color, alpha=0.35)
    draw_contour(out, gt_mask, (255, 255, 255), thickness=3)
    draw_contour(out, gt_mask, color, thickness=2)
    draw_legend(out, title)
    return out


def main():
    parser = argparse.ArgumentParser(description="GT+预测掩模对比（压力/剪切分开）")
    parser.add_argument("--test-file", default=DEFAULT_TEST_FILE)
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--type", choices=("pressure", "shear", "both"), default="pressure",
                        help="生成哪种掩模，默认仅压力")
    parser.add_argument("--gt-threshold", type=float, default=GT_MASK_THRESHOLD)
    parser.add_argument("--pred-threshold", type=float, default=PRED_SEG_THRESHOLD)
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()

    types = ["pressure", "shear"] if args.type == "both" else [args.type]

    pairs = parse_test_pairs(args.test_file)
    if args.limit > 0:
        pairs = pairs[:args.limit]

    device = torch.device("cpu" if args.cpu or not torch.cuda.is_available() else "cuda")
    net = ForceNet(device)
    output_dir = Path(args.output_dir)

    missing_images = 0
    failed = 0

    for flow_path, label_path in tqdm(pairs, desc=args.type):
        image_path = flow_path_to_image_path(flow_path)
        if not image_path.is_file() or not Path(label_path).is_file():
            missing_images += 1
            continue

        image = cv2.imread(str(image_path))
        if image is None:
            failed += 1
            continue

        try:
            gt_pre, gt_she = load_gt_masks(label_path, args.gt_threshold)

            flow = load_flow(flow_path)
            flow_tensor = torch.from_numpy(flow).permute(2, 0, 1).unsqueeze(0).float().to(device)
            with torch.inference_mode():
                seg_probs, _, _ = net(flow_tensor)
            pred_pre = seg_probs[0, 0].float().cpu().numpy() >= args.pred_threshold
            pred_she = seg_probs[0, 1].float().cpu().numpy() >= args.pred_threshold

            sensor = image_path.parent.parent.name
            stem = image_path.stem
            masks = {
                "pressure": (gt_pre, pred_pre),
                "shear": (gt_she, pred_she),
            }

            for kind in types:
                cfg = MASK_TYPES[kind]
                gt_mask, pred_mask = masks[kind]
                out_path = output_dir / kind / sensor / f"{stem}.jpg"
                out_path.parent.mkdir(parents=True, exist_ok=True)
                cv2.imwrite(
                    str(out_path),
                    make_overlay(image, gt_mask, pred_mask, cfg["color"], cfg["title"]),
                )
        except Exception:
            failed += 1

    per_sample = len(types)
    print(f"完成: {len(pairs)} 条 × {per_sample} 类 = {len(pairs) * per_sample} 张")
    for kind in types:
        print(f"  {kind}: {output_dir / kind}")
    if missing_images:
        print(f"缺少原图或标签: {missing_images}")
    if failed:
        print(f"处理失败: {failed}")


if __name__ == "__main__":
    main()
