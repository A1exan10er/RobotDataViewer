#!/usr/bin/env python3
"""四点鸟瞰矫正（供 main 拉流/透视用；不含曲线填充）。

640x360 四角（最新直线原始交点）:
  TL  L3∩L4   55.9, -38.8
  TR  L3∩L2  607.4,  67.2
  BR  L1∩L2  602.9, 281.3
  BL  L1∩L4   66.6, 400.2
  完整 H 后截断 u>517.1

640x480 四角:
  TL  L3∩L4   57.5,  -8.6
  TR  L3∩L2  603.4, 105.3
  BR  L1∩L2  609.5, 358.9
  BL  L1∩L4   69.3, 484.7
  完整 H 后截断 u>530
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional, Sequence, Tuple

import cv2
import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent

SRC_POINTS_640x480: list[tuple[float, float, str]] = [
    (57.5, -8.6, "L3xL4"),
    (603.4, 105.3, "L3xL2"),
    (609.5, 358.9, "L1xL2"),
    (69.3, 484.7, "L1xL4"),
]

SRC_POINTS_640x360: list[tuple[float, float, str]] = [
    (55.9, -38.8, "L3xL4"),
    (607.4, 67.2, "L3xL2"),
    (602.9, 281.3, "L1xL2"),
    (66.6, 400.2, "L1xL4"),
]

BIRD_CROP_U_MAX_640x360 = 517.1
BIRD_CROP_U_MAX_640x480 = 530.0


def parse_res(text: str) -> tuple[int, int]:
    m = text.lower().replace("*", "x").replace("×", "x")
    parts = m.split("x")
    if len(parts) != 2:
        raise ValueError("分辨率格式: 640x360 或 640x480")
    w, h = int(parts[0]), int(parts[1])
    if (w, h) not in {(640, 360), (640, 480)}:
        raise ValueError("仅支持 640x360 或 640x480")
    return w, h


def parse_res_arg(text: str) -> tuple[int, int]:
    """argparse 用：把 ValueError 转成 ArgumentTypeError。"""
    import argparse

    try:
        return parse_res(text)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc


def config_for_res(
    width: int, height: int
) -> tuple[list[tuple[float, float, str]], float | None]:
    if (width, height) == (640, 360):
        return SRC_POINTS_640x360, BIRD_CROP_U_MAX_640x360
    if (width, height) == (640, 480):
        return SRC_POINTS_640x480, BIRD_CROP_U_MAX_640x480
    raise ValueError(f"不支持分辨率 {width}x{height}")


def order_corners(pts: np.ndarray) -> np.ndarray:
    """返回 TL, TR, BR, BL。"""
    pts = np.asarray(pts, dtype=np.float32).reshape(4, 2)
    s = pts.sum(axis=1)
    diff = np.diff(pts, axis=1).reshape(-1)
    tl = pts[np.argmin(s)]
    br = pts[np.argmax(s)]
    tr = pts[np.argmin(diff)]
    bl = pts[np.argmax(diff)]
    return np.array([tl, tr, br, bl], dtype=np.float32)


def birdview_output_size(ordered: np.ndarray) -> tuple[int, int]:
    tl, tr, br, bl = ordered
    w = int(round(max(np.linalg.norm(tr - tl), np.linalg.norm(br - bl))))
    h = int(round(max(np.linalg.norm(bl - tl), np.linalg.norm(br - tr))))
    return max(w, 64), max(h, 64)


def build_homography(
    points: Sequence[tuple[float, float, str]],
    *,
    crop_u_max: float | None = None,
) -> tuple[np.ndarray, np.ndarray, int, int, list[str], int]:
    """
    完整四角生成 H；crop_u_max 仅缩小输出宽度，不改 H。
    返回 (H, ordered, out_w, out_h, labels, full_w)
    """
    raw = np.float32([(u, v) for u, v, _ in points])
    labels = [name for _u, _v, name in points]
    ordered = order_corners(raw)
    ordered_labels: list[str] = []
    for pt in ordered:
        j = int(np.argmin(np.sum((raw - pt) ** 2, axis=1)))
        ordered_labels.append(labels[j])
    full_w, out_h = birdview_output_size(ordered)
    dst = np.float32(
        [[0, 0], [full_w - 1, 0], [full_w - 1, out_h - 1], [0, out_h - 1]]
    )
    H = cv2.getPerspectiveTransform(ordered, dst)
    out_w = full_w
    if crop_u_max is not None and 0 < crop_u_max < full_w:
        out_w = max(64, int(np.floor(crop_u_max)) + 1)
    return H, ordered, out_w, out_h, ordered_labels, full_w


def ensure_size(frame: np.ndarray, width: int, height: int) -> np.ndarray:
    h, w = frame.shape[:2]
    if (w, h) == (width, height):
        return frame
    return cv2.resize(frame, (width, height), interpolation=cv2.INTER_AREA)


def warp_birdview(
    frame: np.ndarray,
    H: np.ndarray,
    out_w: int,
    out_h: int,
    *,
    full_w: int | None = None,
) -> np.ndarray:
    """先按完整宽度 warp，再截宽。不做曲线填充。"""
    ww = full_w if (full_w is not None and full_w > out_w) else out_w
    bird = cv2.warpPerspective(frame, H, (ww, out_h), flags=cv2.INTER_LINEAR)
    if ww > out_w:
        bird = bird[:, :out_w].copy()
    return bird


class NiaokanCorrector:
    """拉流分辨率 → 四点鸟瞰 → 缩放到 save_size（默认 640x360）。"""

    def __init__(
        self,
        width: int = 640,
        height: int = 360,
        *,
        save_size: tuple[int, int] = (640, 360),
        flip_horizontal: bool = False,
        points: Optional[Sequence[tuple[float, float, str]]] = None,
        crop_u_max: float | None = None,
    ):
        if points is None or crop_u_max is None:
            cfg_points, cfg_crop = config_for_res(width, height)
            points = points if points is not None else cfg_points
            crop_u_max = cfg_crop if crop_u_max is None else crop_u_max
        self.width = int(width)
        self.height = int(height)
        self.save_size = (int(save_size[0]), int(save_size[1]))
        self.flip_horizontal = bool(flip_horizontal)
        self.crop_u_max = crop_u_max
        (
            self.H,
            self.ordered,
            self.out_w,
            self.out_h,
            self.labels,
            self.full_w,
        ) = build_homography(list(points), crop_u_max=crop_u_max)

    def info_lines(self) -> List[str]:
        lines = [
            f"输入: {self.width}x{self.height}",
            f"完整鸟瞰: {self.full_w}x{self.out_h}",
            f"截断输出: {self.out_w}x{self.out_h}"
            + (f" (u>{self.crop_u_max:g})" if self.crop_u_max is not None else ""),
            f"下游尺寸: {self.save_size[0]}x{self.save_size[1]}",
            "填充: 无",
        ]
        if self.flip_horizontal:
            lines.append("预处理: 水平翻转")
        return lines

    def correct(self, frame: np.ndarray) -> np.ndarray:
        frame = ensure_size(frame, self.width, self.height)
        if self.flip_horizontal:
            frame = cv2.flip(frame, 1)
        bird = warp_birdview(
            frame, self.H, self.out_w, self.out_h, full_w=self.full_w
        )
        sw, sh = self.save_size
        if bird.shape[1] == sw and bird.shape[0] == sh:
            return bird
        return cv2.resize(bird, (sw, sh), interpolation=cv2.INTER_AREA)
